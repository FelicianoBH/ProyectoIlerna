<div id="header-confeccion-pedidos">
		
			<ul class="header-confeccion-pedidos-nav">
				<li><a href="">Manual</a></li>
				<li><a href="">Automáticos</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion4').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
