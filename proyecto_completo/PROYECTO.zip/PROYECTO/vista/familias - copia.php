<div id="header-familias">
		
			<ul class="header-familias-nav">
				<li><a href="">Confección</a>
				</li>
				<li><a href="">Listados Familias </a>
				</li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Familias";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
