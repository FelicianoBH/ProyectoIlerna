<!DOCTYPE html>
<html>
<head>   
 
	<title>GESTION ARNET</title>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/png" href="../arnetlogo2.png">
 	<link rel="stylesheet" href="fontawesome/css/all.css">
 	<link rel="stylesheet" href="css/estilos.css">

	<!-- BOOTSTRAP CSS -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">

  	<script type="text/javascript" src="../controlador/jquery/jquery-3.4.1.min.js"></script>
 <!-- 	<script type="text/javascript" src="../controlador/jquery/jquery.js"></script><-->
  	<style type="text/css">

*/ 		#principale {
 
  			width:970px;  
  			height:950px; 
  			margin:0 auto;
  			border:1px solid;
  			background-color:white;
  		}
*/
   #esta {

      background-color: blue;
    }

		#principale {
			display:block;
			background-color:#DFECF0;
  			width:75%;
  			min-width:360px;
  			padding: 1%;
  			margin:0 auto;
  			border: groove #0084d1;
  			opacity:0.4;
			margin-top:10%;			
		 	text-align:center;

      }
		} 
  		
		
  	</style>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-4">.col-md-4</strong></div>
      <div class="col-md-4">.col-md-4</div>
      <div class="col-md-4">.col-md-4</div>
    </div>
    
</div>
</body>