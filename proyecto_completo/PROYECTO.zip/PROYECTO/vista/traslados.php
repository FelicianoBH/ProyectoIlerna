<div id="header-traslados">
		
			<ul class="header-traslados-nav">
				<li><a href="gestion.php?op=331">CONFECCION TRASLADOS</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
 