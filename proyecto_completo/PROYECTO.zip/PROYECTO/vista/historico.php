<div id="header-historico">
		
			<ul class="header-historico-nav">
				<li><a href="gestion.php?op=321">Ficha de Stock</a></li>
				<li><a href="gestion.php?op=322">Grupo Movimientos</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
