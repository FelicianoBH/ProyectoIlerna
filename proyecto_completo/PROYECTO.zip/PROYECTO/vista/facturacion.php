<div id="header-ofertas">
		
			<ul class="header-ofertas-nav">
				<li><a href="gestion.php?op=261">Facturacion Directa</a></li>
				<li><a href="gestion.php?op=262">Facturar Pedidos</a></li>
				<li><a href="gestion.php?op=263">Facturar Albaranes</a></li>
				<li><a href="gestion.php?op=264">Consulta Facturas</a></li>
			</ul>
	</div> 
<script type="text/javascript">

	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
