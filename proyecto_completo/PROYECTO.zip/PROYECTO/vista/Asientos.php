<div id="header-asientos">
		
			<ul class="header-asientos-nav">
				<li><a href="">Introducción Apuntes</a></li>
				<li><a href="">Diario Contable</a></li>
				<li><a href="">Consultas y Listados</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+="Asientos Contables";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>


<div id="header-ficheros">
		
			<ul class="header-ficheros-nav">
				<li><a href="">Introducción Apuntes</a></li>
				<li><a href="">Diario Contable</a></li>
				<li><a href="">Consultas y Listados</a></li>
			</ul>
</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion1').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
	