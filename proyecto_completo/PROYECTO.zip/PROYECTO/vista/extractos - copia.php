<div id="header-extractos">
		
			<ul class="header-extractos-nav">
				<li><a href="">Consulta</a></li>
				<li><a href="">Conciliación</a></li>
				<li><a href="">Listados</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Extractos Contables";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
