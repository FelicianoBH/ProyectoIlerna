<div id="header-inventarios">
		
			<ul class="header-inventarios-nav">
				<li><a href="">General</a></li>
				<li><a href="">Rotativo</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
</script>
