<div id="header-extractos">
		
			<ul class="header-extractos-nav">
				<li><a href="gestion.php?op=531">Consulta Individual</a></li>
				<li><a href="gestion.php?op=532">Extractos Grupo</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
</script>
