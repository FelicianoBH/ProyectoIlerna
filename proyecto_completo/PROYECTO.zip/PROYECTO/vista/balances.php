<div id="header-balances">
		
			<ul class="header-balances-nav">
				<li><a href="gestion.php?op=541">Sumas y Saldos</a></li>
				<li><a href="gestion.php?op=542">Situación</a></li>
				<li><a href="">Explotación</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
