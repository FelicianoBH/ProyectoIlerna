<div id="header-devolucion-provedores">
		
			<ul class="header-devolucion-provedores-nav">
				<li><a href="">Registro Pedidos</a></li>
				<li><a href="">Pendientes</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion4').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
