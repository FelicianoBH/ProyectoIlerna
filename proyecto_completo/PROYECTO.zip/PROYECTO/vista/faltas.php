<div id="header-Faltas">
		
</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
</script>
