<div id="header-familias">
		
			<ul class="header-familias-nav">
				<li><a href="gestion.php?op=221">Familias</a>
				</li>
				<li><a href="gestion.php?op=222">Sub-Familias</a>
				</li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
