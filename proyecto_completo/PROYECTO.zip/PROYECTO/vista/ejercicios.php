	<div id="header-ejercicio">
		
			<ul class="header-ejercicio-nav">
				<li><a href="">Cierre</a>
				</li>
				<li><a href="">Apertura</a>
				</li>
			</ul>
	</div>

	<script type="text/javascript">
	
	document.getElementById('lateral-opcion1').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
	