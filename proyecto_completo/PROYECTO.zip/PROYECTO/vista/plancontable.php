<div id="header-plancontable">
		
			<ul class="header-plancontable-nav">
				<li><a href="">Maestro de Cuentas</a></li>
				<li><a href="">Consultas y Listados</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Plan Contable ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
