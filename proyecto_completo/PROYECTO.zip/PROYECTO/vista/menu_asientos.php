<div id="header-asientos">
		
			<ul class="header-asientos-nav">
				<li><a href="gestion.php?op=521">Introducción Apuntes</a></li>
				<li><a href="gestion.php?op=522">Diario Contable</a></li>
				<li><a href="">Consultas y Listados</a></li>
			</ul>
</div>

<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	/*document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";*/
	
</script>
	