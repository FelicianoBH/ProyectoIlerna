<script type="text/javascript">
	
	window.location.assign("index.php");

</script>
