<!DOCTYPE html>
<html>
<head>
  <title></title>

  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/png" href="../../arnetlogo2.png">
  <link rel="stylesheet" href="../fontawesome/css/all.css">
  <link rel="stylesheet" href="../css/estilos.css">

  <!-- BOOTSTRAP CSS -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../bootstrap/css/bootstrap-theme.min.css">

    <script type="text/javascript" src="../controlador/jquery/jquery-3.4.1.min.js"></script>
 <!--   <script type="text/javascript" src="../controlador/jquery/jquery.js"></script><-->
    <style type="text/css">

</head>
<body>
<div class="container">
  <div class="row align-items-center">
    <div class="col">
      Columna 1
    </div>
    <div class="col">
      Columna 2
    </div>
    <div class="col">
      Columna 3
    </div>
  </div>
</div>
<div class="container">
  <div class="row align-items-end">
    <div class="col">
      Columna 1
    </div>
    <div class="col">
      Columna 2
    </div>
    <div class="col">
      Columna 3
    </div>
  </div>
</div>
</body>
</html>




