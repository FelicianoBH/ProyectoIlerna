			$texto="'";
			$table .= '<td><input id="'.$seleccionar.$fila['CONCEPTO_ID'].'" onclick = "seleccionarConceptoEdicion('.$texto.$fila['CONCEPTO_ID'].$texto.')" type = "button" value ="Seleccionar" class = "btn btn-success" ></td>'; 
			$table .= '</tr>';
