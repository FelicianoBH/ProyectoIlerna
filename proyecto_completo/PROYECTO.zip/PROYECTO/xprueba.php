<!DOCTYPE html>
<html>
<head>
	<title>Prueba de fondos</title>
	<link rel="stylesheet" href="normalize.css">
	<style type="text/css">

		#bordy {
			
			height:900px;
			background:url("fondo1.png");
  			opacity:0.2;
		} 
		#usuario{

		
			background-color:#DEECF0;
			
		}

		h2	{

				font-size:22px;
				color:#000080;
			}
		button {
			margin-left: 20%;
			display:block;
			width:110px;
			height:40px;
			font-size:16px;
			font-weight:bold;
			text-align:left;
			color: #000080;
			border:1px #000080 solid;
			border-radius:10%;
		}

		h4  {
				font-size:14px;
				color:#000080;
		}
		h5  	{
				font-size:14px;
				color:#000080;
		}



		table {

			
			
			margin:auto;

		}

			.izq {
				color:#000080;
				font-size:22px;
				text-align:right;
			}
			.der {
				color:#000080;
				text-align:left;
			}

			td {
				text-align:center;
				padding:10px;
			}
			#i1, #i2 {
				color:#000080;
				
			}

			.boton {

				font-size:18px;
				background-color:white;
				color:#000080;
			}


		
	</style>
</head>
<body >

	<div id="bordy"></div>


	<!--
	<div  id="principale">
		<img src="logo.png" width="200px" height="60">
		
		<p><h2>ADMINISTRACIÓN Y EXPLOTACIÓN DE RECURSOS</h2></p>
		<p><h4>GESTION DE NEGOCIOS EN LA WEB</h4></p>
		<p><h4>COMERCIAL - LOGÍSTICA - CONTABILIDAD</h4></p>
		
			<div id="usuario">
				<img src="logolg.jpg" width="120px" height="100">
				<h5>ACCESO RESTRINGIDO A USUARIOS DE LA ORGANIZACION</h5>
			
				<h2> Introduce tus Datos</h2>
					<form action="comprueba_login2.php" method="post">
						<table>
							<tr>
								<td class="izq">Login:</td>
								<td class="der"><input  id="i1" type="text" name="login"></td>
							</tr>
							<tr>
								<td class="izq">Password:</td>
								<td class="der"><input id="i2" type="password" name="password"></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" class="boton" name="enviar" value="LOGIN">
								</td>
							</tr>
						</table>
					</form>
			</div>
	</div>

	-->
		
</body>
</html>