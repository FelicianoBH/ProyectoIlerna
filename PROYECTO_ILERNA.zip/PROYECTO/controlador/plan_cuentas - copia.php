<div id="header-referencias">
		<div id="titulo-referencias">
 			<div>Plan de Cuentas</div>
		</div>
</div>
<br><br>
<div id="overlay"></div>
<div id="nuevaVentana">
	<div id="box-header">Añadir Cuenta</div>
	<button onmousedown="ejecutarNuevaVentana()" class="btn btn-primary" id="botonCerrar">
		<i class="fa  fa-door-open"></i>
	</button><br><br><br>
		<label style="margin-left:10%;">Codigo Cuenta: </label><input type="text" id ="nuevaCuentaId"/><br><br>
		<label style="margin-left:10%;">Titulo: </label><input type="" id="nuevoTituloId"/><br><br>
		<label style="margin-left:10%;">Masa Patrimonial: </label><input type="" id="nuevaMasaPatrimonialId"/><br><br>
		<label style="margin-left:10%;">Grado: </label><input type="" id="nuevoGradoId"/><br><br>
		<label style="margin-left:10%;">Desarrollo: </label><input type="" id="nuevoDesarrolloId"/><br><br>
		<label style="margin-left:10%;">Con Enlace: </label><input type="" id="nuevoConEnlaceId"/><br><br>
	<button onmousedown="agregarCuenta()" style="margin-left:40%;" class="btn btn-success">Añadir Cuenta</button><br>
</div>

<div id="wrapper">
	<div id="crud_gral"></div>
</div>

<script type="text/javascript">
	

	var resultado = document.getElementById("crud_gral");
	document.getElementById("nuevaVentana").style.height="400px";
	var num_registros;
	var num_paginas;
	var pagina_actual;
	var muestro_pagina;
	var actualizando=false;
 
	function mostrarCuentas(pagina){

		pagina_actual=pagina;

		num_paginas= Math.ceil(num_registros/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				resultado.innerHTML = xmlhttp.responseText;

				var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
				enBoton.style.background="#679B9B";
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_plan_cuentas.php?cuentas=" + "cuentas"+"&pagina="+pagina+"&num_paginas="+num_paginas, true);
		xmlhttp.send();
	}


	function preparoMostrarCuentas(){

			var xmlhttp;
			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {

 				num_registros = xmlhttp.responseText;
				mostrarCuentas(1);

				}
		}
		xmlhttp.open("GET", "../modelo/modelo_plan_cuentas.php?acontar="+"si", true);
		xmlhttp.send();
	}

	preparoMostrarCuentas();

	function retrocedoPagina() {

		if (pagina_actual > 1) {

			muestro_pagina = pagina_actual - 1;

			mostrarCuentas(muestro_pagina);

		}

	}

	function avanzoPagina() {

		
		if (pagina_actual < num_paginas) {

			muestro_pagina = pagina_actual + 1;

			mostrarCuentas(muestro_pagina);

		}

	}



	function editarCuentas(id) {

		if (!actualizando) {

		actualizando=true;

		var codigo_cuentaID="CODIGO_CUENTA" + id;
		var tituloID="TITULO"+id;
		var masa_patrimonialID="MASA_PATRIMONIAL"+id;
		var gradoID="GRADO"+id;
		var desarrolloID="DESARROLLO"+id;
		var con_enlaceID="CON_ENLACE"+id;



		var borrar = "BORRAR" + id;
		var actualizar = "ACTUALIZAR" + id;

		var editarcodigo_cuentaID=codigo_cuentaID+"-editar";
		var editartituloID=tituloID+"-editar";
		var editarmasa_patrimonialID=masa_patrimonialID+"-editar";
		var editargradoID=gradoID+"-editar";
		var editardesarrolloID=desarrolloID+"-editar";
		var editarcon_enlaceID=con_enlaceID+"-editar";


		var codigo_cuenta=document.getElementById(codigo_cuentaID).innerHTML; 
		var titulo=document.getElementById(tituloID).innerHTML;
		var masa_patrimonial=document.getElementById(masa_patrimonialID).innerHTML;
		var grado=document.getElementById(gradoID).innerHTML;
		var desarrollo=document.getElementById(desarrolloID).innerHTML;
		var con_enlace=document.getElementById(con_enlaceID).innerHTML;


		var parent= document.querySelector("#" + codigo_cuentaID);

		if (parent.querySelector("#" + editarcodigo_cuentaID) === null ) {


			document.getElementById(tituloID).innerHTML = '<input type ="text" id="'+editartituloID+'" value="'+titulo+'">';
			document.getElementById(masa_patrimonialID).innerHTML = '<input type ="text" id="'+editarmasa_patrimonialID+'" value="'+masa_patrimonial+'">';
			document.getElementById(gradoID).innerHTML = '<input type ="text" id="'+editargradoID+'" value="'+grado+'">';
			document.getElementById(desarrolloID).innerHTML = '<input type ="text" id="'+editardesarrolloID+'" value="'+masa_patrimonial+'">';
			document.getElementById(con_enlaceID).innerHTML = '<input type ="text" id="'+editarcon_enlaceID+'" value="'+con_enlace+'">';


			document.getElementById(borrar).disabled="true";
			document.getElementById(actualizar).style.display="block";
		}
	}
}

	function actualizarCuentas(id){

		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		var tituloActualizado= document.getElementById("TITULO"+id+"-editar").value;
		var masa_patrimonialActualizada= document.getElementById("MASA_PATRIMONIAL"+id+"-editar").value;
		var gradoActualizado= document.getElementById("GRADO"+id+"-editar").value;
		var desarrolloActualizado= document.getElementById("DESARROLLO"+id+"-editar").value;
		var con_enlaceActualizado= document.getElementById("CON_ENLACE"+id+"-editar").value;

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

 				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
 				 	preparoMostrarCuentas();
 				 	actualizando=false;
			}

	}

		xmlhttp.open("GET", "../modelo/modelo_plan_cuentas.php?param1="+id+"&param2="+tituloActualizado+"&param3="+masa_patrimonialActualizada+"&param4="+gradoActualizado+"&param5="+desarrolloActualizado+"&param6="+con_enlaceActualizado, true);
		xmlhttp.send();
	
}
		

		function borrarCuenta(id) {


			var respuesta = confirm("Estas seguro de borrar esta Cuenta?");
			
			if (respuesta ===true ) {

				var xmlhttp;

				if(window.XMLHttpRequest) {
					
					xmlhttp = new XMLHttpRequest();

					} else {

					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

					}
				
				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				preparoMostrarCuentas();

				}
			}

				xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?refeliminada="+id,true);
				xmlhttp.send();
		
		 }
	}


	var overlay = document.getElementById("overlay");
	var nuevaVentana= document.getElementById("nuevaVentana");

	function ejecutarNuevaVentana(){


		overlay.style.opacity = .7;

		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}
		document.getElementById("nuevaCuentaId").value="";
		document.getElementById("nuevoTituloId").value="";
		document.getElementById("nuevaMasaPatrimonialId").value="";
		document.getElementById("nuevoGradoId").value="";
		document.getElementById("nuevoDesarrolloId").value="";
		document.getElementById("nuevoConEnlaceId").value="";
	}

	function agregarCuenta() {

		overlay.style.display ="none";
		nuevaVentana.style.display = "none";

		var xmlhttp;

			if(window.XMLHttpRequest) {
					xmlhttp = new XMLHttpRequest();
					} else {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}

	 	var nuevaCuenta=document.getElementById("nuevaCuentaId").value;	
	 	var nuevoTitulo=document.getElementById("nuevoTituloId").value;
	 	var nuevaMasaPatrimonial=document.getElementById("nuevaMasaPatrimonialId").value;
	 	var nuevoGrado=document.getElementById("nuevoGradoId").value;
	 	var nuevoDesarrollo=document.getElementById("nuevoDesarrolloId").value;
	 	var nuevoConEnlace=document.getElementById("nuevoConEnlaceId").value;


				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
 				preparoMostrarCuentas();

 				}
			}


 		xmlhttp.open("GET", "../modelo/modelo_plan_cuentas.php?nuevaCuenta="+nuevaCuenta+"&nuevoTitulo="+nuevoTitulo+"&nuevaMasaPatrimonial="+nuevaMasaPatrimonial+"&nuevoGrado="+nuevoGrado+"&nuevoDesarrollo="+nuevoDesarrollo+"&nuevoConEnlace="+nuevoConEnlace, true);
		xmlhttp.send();
		
					 
	}

</script>


					