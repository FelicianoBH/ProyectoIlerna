<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>



<div id="header-ficheros">
		
			<ul class="header-ficheros-nav">
				<li><a href="referencias_generales.php">Referencias Generales</a>
				</li>
				<li><a href="">Cuentas Maestras</a>
				</li>
				<li><a href="">Almacenes</a>
				</li>
				<li><a href="">Conceptos Contables</a>
				</li>
			</ul>
</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion1').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
</body>
</html>

