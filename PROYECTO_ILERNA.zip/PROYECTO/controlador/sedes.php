<div id="header-referencias">
		<div id="titulo-referencias">
 			<div>Sedes/Almacenes</div>
		</div>
</div>
<br><br>
<div id="overlay"></div>
<div id="nuevaVentana">
	<div id="box-header">Añadir Sedes</div>
	<button onmousedown="ejecutarNuevaVentana()" class="btn btn-primary" id="botonCerrar">
		<i class="fa  fa-door-open"></i>
	</button><br><br><br>
		<label style="margin-left:10%;">Número de Sede</label><input type="text" id ="nuevaId_SedeId"/><br><br>
		<label style="margin-left:10%;">Nombre: </label><input type="" id="nuevoNombreId"/><br><br>
		<label style="margin-left:10%;">Descripción </label><input type="" id="nuevaDescripcionId"/><br><br>
		<label style="margin-left:10%;">Dirección</label><input type="" id="nuevaDireccionId"/><br><br>
		<label style="margin-left:10%;">Responsable: </label><input type="" id="nuevaId_ResponsableId"/><br><br>
		<span id="feedback"></span>
	<button onmousedown="agregarSede()" style="margin-left:40%;" class="btn btn-success">Añadir Sede</button><br>
</div>

<div id="wrapper">
	<div id="crud_gral"></div>
</div>

<script type="text/javascript">
	

	var resultado = document.getElementById("crud_gral");
	document.getElementById("nuevaVentana").style.height="20%";
	var num_registros;
	var num_paginas;
	var pagina_actual;
	var muestro_pagina;
	var actualizando=false;
 
	function mostrarSedes(pagina){

		pagina_actual=pagina;

		num_paginas= Math.ceil(num_registros/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				resultado.innerHTML = xmlhttp.responseText;

				var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
				enBoton.style.background="#679B9B";
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_sedes.php?sedes=" + "sedes"+"&pagina="+pagina+"&num_paginas="+num_paginas, true);
		xmlhttp.send();
	}


	function preparoMostrarSedes(){

			var xmlhttp;
			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {

 				num_registros = xmlhttp.responseText;
				mostrarSedes(1);

				}
		}
		xmlhttp.open("GET", "../modelo/modelo_sedes.php?acontar="+"si", true);
		xmlhttp.send();
	}

	preparoMostrarSedes();

	function retrocedoPagina(hastaDonde) {

		if (hastaDonde=="inicio"){

				mostrarSedes(1);

		} else {

			if (pagina_actual > 1) {

				muestro_pagina = pagina_actual - 1;

				mostrarSedes(muestro_pagina);
			}
		}
	}

	function avanzoPagina(hastaDonde, paginaFinal) {

		if (hastaDonde=="final") {

				mostrarSedes(paginaFinal);
 
		} else {
 
		if (pagina_actual < num_paginas) {

			muestro_pagina = pagina_actual + 1;

			mostrarSedes(muestro_pagina);

			}
		}

	}

	function editarSedes(id) {


		if (!actualizando) {

		actualizando=true;
		var id_sedeID="ID_SEDE" + id;
		var nombreID="NOMBRE"+id;
		var descripcionID="DESCRIPCION"+id;
		var direccionID="DIRECCION"+id;
		var id_responsableID="ID_RESPONSABLE"+id;
		var borrar = "BORRAR" + id;
		var actualizar = "ACTUALIZAR" + id;

		var editarid_sedeID=id_sedeID+"-editar";
		var editarnombreID=nombreID+"-editar";
		var editardescripcionID=descripcionID+"-editar";
		var editardireccionID=direccionID+"-editar";
		var editarid_responsableID=id_responsableID+"-editar";

		var id_sede=document.getElementById(id_sedeID).innerHTML; 
		var nombre=document.getElementById(nombreID).innerHTML;
		var descripcion=document.getElementById(descripcionID).innerHTML;
		var direccion=document.getElementById(direccionID).innerHTML;
		var id_responsable=document.getElementById(id_responsableID).innerHTML;

		var parent= document.querySelector("#" + id_sedeID);

		if (parent.querySelector("#" + editarid_sedeID) === null ) {


			document.getElementById(nombreID).innerHTML = '<input type ="text" id="'+editarnombreID+'" value="'+nombre+'">';
			document.getElementById(descripcionID).innerHTML = '<input type ="text" id="'+editardescripcionID+'" value="'+descripcion+'">';
			document.getElementById(direccionID).innerHTML = '<input type ="text" id="'+editardireccionID+'" value="'+direccion+'">';
			document.getElementById(id_responsableID).innerHTML = '<input type ="text" id="'+editarid_responsableID+'" value="'+id_responsable+'">';
			
			document.getElementById(borrar).disabled="true";
			document.getElementById(actualizar).style.display="block";
		}
	}
}

	function actualizarSedes(id) {

		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		
		var nombreActualizado= document.getElementById("NOMBRE"+id+"-editar").value;
		var descripcionActualizada= document.getElementById("DESCRIPCION"+id+"-editar").value;
		var direccionActualizada= document.getElementById("DIRECCION"+id+"-editar").value;
		var id_responsableActualizada= document.getElementById("ID_RESPONSABLE"+id+"-editar").value;
		

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

 				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
					actualizando=false;
 				
 				 	mostrarSedes(pagina_actual);
			}

	}

		xmlhttp.open("GET", "../modelo/modelo_sedes.php?param1="+id+"&param2="+nombreActualizado+"&param3="+descripcionActualizada+"&param4="+direccionActualizada+"&param5="+id_responsableActualizada, true);
		xmlhttp.send();
	
}
		

		function borrarSede(id) {


			var respuesta = confirm("Estas seguro de borrar esta Sedes?");
			
			if (respuesta ===true ) {

				var xmlhttp;

				if(window.XMLHttpRequest) {
					
					xmlhttp = new XMLHttpRequest();

					} else {

					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

					}
				
				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				preparoMostrarSedes();

				}
			}

				xmlhttp.open("GET", "../modelo/modelo_sedes.php?id_sedeeliminada="+id,true);
				xmlhttp.send();
		
		 }
	}


	var overlay = document.getElementById("overlay");
	var nuevaVentana= document.getElementById("nuevaVentana");

	function ejecutarNuevaVentana(){


		overlay.style.opacity = .7;

		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		document.getElementById("feedback").innerHTML="";

		document.getElementById("nuevaId_SedeId").value="";
		document.getElementById("nuevoNombreId").value="";
		document.getElementById("nuevaDescripcionId").value="";
		document.getElementById("nuevaDireccionId").value="";
		document.getElementById("nuevaId_ResponsableId").value="";
	}

	function agregarSede() {


		var nuevaId_Sede=document.getElementById("nuevaId_SedeId").value;	
	 	var nuevoNombre=document.getElementById("nuevoNombreId").value;
	 	var nuevaDescripcion=document.getElementById("nuevaDescripcionId").value;
	 	var nuevaDireccion=document.getElementById("nuevaDireccionId").value;
	 	var nuevaId_Responsable=document.getElementById("nuevaId_ResponsableId").value;

		if (validarAgregar(nuevaId_Sede, nuevoNombre, nuevaDescripcion, nuevaDireccion, nuevaId_Responsable)) {

		overlay.style.display ="none";
		nuevaVentana.style.display = "none";

		var xmlhttp;

			if(window.XMLHttpRequest) {
					xmlhttp = new XMLHttpRequest();
					} else {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}

				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
 				preparoMostrarSedes();

 				}
			}


 		xmlhttp.open("GET", "../modelo/modelo_sedes.php?nuevaId_Sede="+nuevaId_Sede+"&nuevoNombre="+nuevoNombre+"&nuevaDescripcion"+nuevaDescripcion+"&nuevaDireccion="+nuevaDireccion+"&nuevaId_Responsable="+nuevaId_Responsable, true);
		xmlhttp.send();
	  } 
					 
	}


		function validarAgregar(nuevaId_Sede, nuevoNombre, nuevaDescripcion, nuevaDireccion, nuevaId_Responsable) {

			var mensajeFB=document.getElementById("feedback");

		/*	if(nuevaCuenta<100000000000 || nuevaCuenta>999999999999) {return false;}

			if(isNaN(nuevoGrado)) {
				mensajeFB.innerHTML='<button type = "button" value ="Grado no numerico" class = "btn btn-danger">Grado no numerico</button>';
				mensajeFB.style.margin="35%";
				return false;

			}   mensajeFB.innerHTML="";
				return true;   */
				return true;
		}

</script>


					