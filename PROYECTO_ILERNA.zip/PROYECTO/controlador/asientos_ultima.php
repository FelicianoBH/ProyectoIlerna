<div id="header-referencias">
		<div id="titulo-referencias">
 			<div>Input Contabilidad</div>
		</div>   
</div>  
<div id="overlay"></div>
<div id="nuevaVentana">
	<div id="box-header"> Consulta </div>
	<button onmousedown="ejecutarNuevaVentana()" class="btn btn-primary" id="botonCerrar">
		<i class="fa  fa-door-open"></i>
	</button><br><br><br>
	<div id="pantallaConsulta"> 
	</div>
		<span id="feedback"></span>
</div>
<div id="wrapper"> 
	<div id="crud_gral">
	  <div id="input-apuntes">
	  <form>
			<fieldset>
      			<div id="div1">
					<label for="usuario">Usuario: </label>    
					<input type="text" id="usuario" placeholder="<?php echo $_SESSION["usuario"] ?>" readonly="readonly" size="20" />
      			</div>
      			<div id="div2">
					<label for="fecha">Fecha Contable: </label>    
					<input type="text" id="fecha"  readonly="readonly" size="12"/>
      			</div>
      			<div id="div3">
					<label for="asiento">Asiento: </label>    
					<input type="text" id="asiento" readonly="readonly" size="6"/>
      			</div>
      			<div id="div4">
					<label for="apunte">Apunte: </label>    
					<input type="text" id="apunte" readonly="readonly" size="6"/>
      			</div>
      		</fieldset>

      		<fieldset>
      			<div id="div5">
					<label for="codcuenta">Codigo Cuenta: </label>    
					<input type="text" id="codcuenta" size="12" maxlength="12"/>
					<button type="button" class='botones' onclick="buscaCuenta()">=></button>
      			</div>
				<div id="div6">
					<label for="titulo">Titulo: </label>    
					<input type="text" id="titulo" size="30" maxlength="40"/>
      			</div>
      			<div id="div7">
      				<label>              </label>
					
					<button type="button" class='botones' onclick="ejecutarNuevaVentana('noedicion')">Consulta </button>
					<button type="button" class='botones' onclick="ejecutarNuevaVentanaAlfa('noedicion')">Alfabetica</button>
				</div>
      		</fieldset>
      		<fieldset id="tercerfield">
      			<div id="divA">	
      				<label for="concepto_numero">Núm Concepto: </label>    
					<input type="number" id="concepto_numero" size="4" maxlength="5"/>
					<button  type="button" class='botones' onclick="buscaConceptos()">=></button>
					<input type="text" id="concepto_texto" size="20" maxlength="40"/>
				</div>	
				<div id="divD">
					<label></label>
					<button type="button" class='botones' onclick="consultarConceptos()">Ver conceptos</button>
					<button type="button" class='botones' onclick="botonDebe()">Debe</button>
					<button type="button" class='botones' onclick="botonHaber()">Haber</button>
					<input type="text" id="debehaber" size="5" readonly="readonly"/>
					
				</div>
			</fieldset>
			<fieldset id="cuartofield">
				<div id="divB">
		      		<label for="documento">Documento: </label>    
					<input type="text" id="documento" size="15" maxlength="15" />
				</div>
				<div id="divC">
		      		<label for="importe">Importe: </label>    
					<input type="text" id="importe" size="10" maxlength="9"/>
					<button type="button" class='botones' onclick="validarApunte()">Validar Apunte</button>
					<button type="button" class='botones' onclick="buscaAlfa()">Cerrar Asiento</button>
				</div>
      		</fieldset>
      		<fieldset id="fieldsetespacio">
      			<div id="divespacio">
      				<label><br></label>
      			</div>
      		</fieldset>
  		</form>
	  </div>
	<div id="muestra-apuntes"><br></div>
	</div>
</div>

<script type="text/javascript">


	var user="<?php echo $_SESSION["usuario"] ?>"
	var resultado = document.getElementById("crud_gral");
	var resultadoconsulta=document.getElementById("pantallaConsulta");
	document.getElementById("nuevaVentana").style.height="60%";
	document.getElementById("nuevaVentana").style.width="70%";
	var num_registros;
	var num_registrosc;
	var num_paginas;
	var pagina_actual;
	var muestro_pagina;
	var num_paginasc;
	var pagina_actualc;
	var muestro_paginac;
	var num_paginasn;
	var pagina_actualn;
	var cuentaposible="no";
	var muestro_paginan;
	var pagina_actualConcepto;
	var muestro_paginaConcepto;
	var num_paginasConcepto;
    var num_registrosConcepto;
	var actualizando=false;
	
			var guardocuenta="";
			var guardoidconcepto="";
			var guardoconcepto="";
			var guardodebeohaber="";
			var guardoimportedebe="";
			var guardoimportehaber="";

 		 v_cuentaid="";
		 v_documentoid="";
		 v_id_conceptoid="";
		 v_conceptoid="";
		 v_debe_o_haberid="";
		 v_importe_debeid="";
		 v_importe_haberid="";

	
			var lafecha = "";
			var elasiento = "";
			var elapunte ="";
	
	function leerRef()  {

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

			 	var obj = JSON.parse(xmlhttp.responseText);
			 	
				lafecha = document.getElementById("fecha");
				elasiento = document.getElementById("asiento");
				elapunte =document.getElementById("apunte");

				document.getElementById("concepto_numero").value="";
				document.getElementById("concepto_texto").value="";
				document.getElementById("debehaber").value="";
				document.getElementById("codcuenta").value="";
				document.getElementById("titulo").value="";
				document.getElementById("documento").value="";
				document.getElementById("importe").value="";
				
				lafecha.value=obj.fechaRef;
				elasiento.value=obj.asientoRef;
				apunteactual=obj.apunteRef;
				elapunte.value=apunteactual; 
				apunte_fecha=lafecha.value;
				apunte_asiento=obj.asientoRef;
				

				alert("lafecha.value: "+lafecha.value + " apunte_fecha : "+apunte_fecha);

			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?leer_ref="+'leer_ref', true);
		xmlhttp.send();      

	}
		function buscaConceptos(){

		var concepto_numero =document.getElementById("concepto_numero").value;

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				var obj = JSON.parse(xmlhttp.responseText);

				document.getElementById("concepto_texto").value=obj.concepto;
				document.getElementById("debehaber").value=obj.debehaber;

			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?concepto_numero="+concepto_numero, true);
		xmlhttp.send();

	} 

		function validarApunte() {


			var respuesta = confirm("Confirma grabar el Apunte Contable") 
			
			if (respuesta ===true ) {

			// recabar y verificar datos del apunte: cuenta, concepto, documento, debe/haber, importe.


			var agrabar_fecha=document.getElementById("fecha").value;
			var agrabar_asiento=document.getElementById("asiento").value;
			var agrabar_apunte=document.getElementById("apunte").value;

			if (document.getElementById("titulo")) {
				var agrabar_titulo=document.getElementById("titulo").value;
					if (agrabar_titulo=="CUENTA INEXISTENTE") { alert("Cuenta inexistente");}
			} else { alert("Revise la Cuenta");}

			if (document.getElementById("codcuenta")) {
				var agrabar_cuenta=document.getElementById("codcuenta").value;
			} else { alert("Revise el Codigo de Cuenta");}

			if (document.getElementById("concepto_numero")) {
				var agrabar_concepto_numero=document.getElementById("concepto_numero").value;
			} else { var agrabar_concepto_numero=0;}

			if(document.getElementById("concepto_texto")) {
				var agrabar_concepto_texto=document.getElementById("concepto_texto").value;
				if (abrabar_concepto_texto="") {alert("Es necesario Concepto Contable");}
			} else {alert("Es necesario Concepto Contable");}

			if(document.getElementById("debehaber")) {
				var agrabar_debehaber=document.getElementById("debehaber").value;
				if (agrabar_debehaber!="DEBE" && agrabar_debehaber!="HABER") {
					alert("Especifique DEBE o HABER ");
				}
			}

			if(document.getElementById("documento")) {
				var agrabar_documento=document.getElementById("documento").value;
			} else { var agrabar_documento=""};

			if(document.getElementById("importe")) {
				var agrabar_importe=document.getElementById("importe").value;
				if (abrabar_importe=0)  {alert("Importe CERO");}
			} else { alert("Es necesario el Importe ");}

			// regrabar la tabla referencias:

			grabaReferencias(agrabar_debehaber,  agrabar_importe);

			// grabar la tabla de apuntes:

			grabaApuntes(agrabar_fecha, agrabar_asiento, agrabar_apunte, agrabar_cuenta, agrabar_debehaber, agrabar_documento, agrabar_importe, agrabar_concepto_numero, agrabar_concepto_texto);

			// graba importe al debe o haber de cuentas y SOLO A TERCER GRADO

			grabaCuentas(agrabar_cuenta, agrabar_importe, agrabar_debehaber);

			// y vuelta a empezar....:

			Inicio();

		}	

	}

	function grabaReferencias(agrabar_debehaber,  agrabar_importe)	{

			var xmlhttp;

			if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
			} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
		
			xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				if (xmlhttp.responseText=="Error"){

					alert("Error de grabacion Referencias");
				}
				
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?agrabar_ref="+"si"+"&agrabar_debehaber="+agrabar_debehaber+"&agrabar_importe="+agrabar_importe, true);
		xmlhttp.send();
 
	}


		function grabaApuntes(agrabar_fecha, agrabar_asiento, agrabar_apunte, agrabar_cuenta, agrabar_debehaber, agrabar_documento, agrabar_importe, agrabar_concepto_numero, agrabar_concepto_texto) {

			var xmlhttp;
			if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
			} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				if (xmlhttp.responseText=="Error"){
					alert("Error de grabacion Referencias");
				} 
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?agrabar_apu="+"si"+"&agrabar_fecha="+agrabar_fecha+"&agrabar_asiento="+agrabar_asiento+"&agrabar_apunte="+agrabar_apunte+"&agrabar_cuenta="+agrabar_cuenta+"&agrabar_debehaber="+agrabar_debehaber+"&agrabar_documento="+agrabar_documento+"&agrabar_importe="+agrabar_importe+"&agrabar_concepto_numero="+agrabar_concepto_numero+"&agrabar_concepto_texto="+agrabar_concepto_texto, true);

		xmlhttp.send();

	}

	function grabaCuentas(agrabar_cuenta, agrabar_importe, agrabar_debehaber) {


			var xmlhttp;
			if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
			} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				if (xmlhttp.responseText=="Error"){
					alert("Error de grabacion Cuentas");
				}
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?agrabar_cta="+"si"+"&agrabar_cuenta="+agrabar_cuenta+"&agrabar_importe="+agrabar_importe+"&agrabar_debehaber="+agrabar_debehaber, true);

		xmlhttp.send();

	}


		function buscaPlan(){

		}
		function buscaAlfa(){

		}

		function botonDebe() {

			document.getElementById("debehaber").value="DEBE";
		}
		function botonHaber() {

			document.getElementById("debehaber").value="HABER";
		}

		function buscaCuenta() {

			document.getElementById("nuevaVentana").style.width="70%";
			var codigo_cuenta=document.getElementById("codcuenta").value;
			
			var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

			document.getElementById("titulo").value= xmlhttp.responseText;

			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?cuenta="+codigo_cuenta, true);
		xmlhttp.send();

	}


	function buscarCuentaB() {
			
			var codigo_cuenta=document.getElementById("nuevaCuentaId").value;
			var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

			document.getElementById("nuevoTituloId").value = xmlhttp.responseText;

			var nuevotitulox=document.getElementById("nuevoTituloId").value;

			if (document.getElementById("nuevoTituloId").value=="INEXISTENTE" ||
				document.getElementById("nuevoTituloId").value=="") {

						cuentaposible="no"
					}
					else
						{
							cuentaposible="si";
					}
			} 
		} 

		xmlhttp.open("GET", "../modelo/modelo_asientos.php?cuenta="+codigo_cuenta, true);
		xmlhttp.send();

	}


	var resultado = document.getElementById("muestra-apuntes");


	
	function mostrarApuntes(pagina){

		pagina_actual=pagina;

		num_paginas= Math.ceil(num_registros/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				resultado.innerHTML = xmlhttp.responseText;

				var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
				
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?apuntes=" + "apuntes"+"&pagina="+pagina+"&num_paginas="+num_paginas, true);
		xmlhttp.send();
	}


	function preparoMostrarApuntes(){

			var xmlhttp;

			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {

 				num_registros = xmlhttp.responseText;

				mostrarApuntes(1);

				}
		}
		xmlhttp.open("GET", "../modelo/modelo_asientos.php?acontarapuntes="+"si", true);
		xmlhttp.send();
	}

		Inicio();

	function Inicio() {

		leerRef();
		
		preparoMostrarApuntes();
	}

	function retrocedoPaginaConcepto() {

			if (pagina_actualConcepto > 1) {
				muestro_paginaConcepto = pagina_actualConcepto - 1;
				mostrarConceptos(muestro_paginaConcepto);
			}
		
		}

	function avanzoPaginaConcepto() {

		if (pagina_actualConcepto < num_paginasConcepto) {
			muestro_paginaConcepto = pagina_actualConcepto + 1;
			mostrarConceptos(muestro_paginaConcepto);

			}
		}
	function retrocedoPaginaConceptoEdicion() {

			if (pagina_actualConcepto > 1) {
				muestro_paginaConcepto = pagina_actualConcepto - 1;
				mostrarConceptosEdicion(muestro_paginaConcepto);
			}
		
		}

	function avanzoPaginaConceptoEdicion() {

		if (pagina_actualConcepto < num_paginasConcepto) {
			muestro_paginaConcepto = pagina_actualConcepto + 1;
			mostrarConceptosEdicion(muestro_paginaConcepto);

			}
		}


	function retrocedoPagina() {

			if (pagina_actual > 1) {
				muestro_pagina = pagina_actual - 1;
				mostrarApuntes(muestro_pagina);
			}
		}

	function avanzoPagina() {

		if (pagina_actual < num_paginas) {
			muestro_pagina = pagina_actual + 1;
			mostrarApuntes(muestro_pagina);
			}
		}

	function retrocedoPaginaC() {

			if (pagina_actualc > 1) {
				muestro_paginac = pagina_actualc - 1;
				mostrarCuentas(muestro_paginac,"noedicion");
			}
		}

	function avanzoPaginaC() {

		if (pagina_actualc < num_paginasc) {
			muestro_paginac = pagina_actualc + 1;
			mostrarCuentas(muestro_paginac,"noedicion");

			}

		}

	function retrocedoPaginaB() {

			if (pagina_actualc > 1) {
				muestro_paginac = pagina_actualc - 1;
				mostrarCuentas(muestro_paginac,"edicion");
			}
		}

	function avanzoPaginaB() {

		if (pagina_actualc < num_paginasc) {
			muestro_paginac = pagina_actualc + 1;
			mostrarCuentas(muestro_paginac,"edicion");
			}
		}


	function retrocedoPaginaAlfa() {
		
			if (pagina_actualc > 1) {
				muestro_paginac = pagina_actualc - 1;
				mostrarCuentasAlfa(muestro_paginac,"edicion");
		}
	}

	function avanzoPaginaAlfa() {

		if (pagina_actualc < num_paginasc) {
			muestro_paginac = pagina_actualc + 1;
			mostrarCuentasAlfa(muestro_paginac,"edicion");
			}
	}

	var guardocuenta="";

	function editarApunte(id) {

		if (!actualizando) {

		actualizando=true;
		var apunteID="APUNTE" + id;
		var cuentaID="CUENTA"+id;
		var documentoID="DOCUMENTO"+id;
		var id_conceptoID="ID_CONCEPTO"+id;
		var conceptoID="CONCEPTO"+id;
		var debe_o_haberID="DEBE_HABER"+id;
		var importe_debeID="IMPORTED"+id;
		var importe_haberID="IMPORTEH"+id;
		var borrar = "BORRAR" + id;
		var actualizar = "ACTUALIZAR" + id;
		alert("apunteID: "+apunteID);
		var editarapunteID=apunteID+"-editar";
		var editarcuentaID=cuentaID+"-editar";
		var editardocumentoID=documentoID+"-editar";
		var editarid_conceptoID=id_conceptoID+"-editar";
		var editarconceptoID=conceptoID+"-editar";
		var editardebe_o_haberID=debe_o_haberID+"-editar";
		var editarimporte_debeID=importe_debeID+"-editar";
		var editarimporte_haberID=importe_haberID+"-editar";

		var apunte=document.getElementById(apunteID);
		var cuentaid=document.getElementById(cuentaID).innerHTML;
		var documentoid=document.getElementById(documentoID).innerHTML;
		var id_conceptoid=document.getElementById(id_conceptoID).innerHTML;
		var conceptoid=document.getElementById(conceptoID).innerHTML;
		var debe_o_haberid=document.getElementById(debe_o_haberID).innerHTML;
		var importe_debeid=document.getElementById(importe_debeID).innerHTML;
		var importe_haberid=document.getElementById(importe_haberID).innerHTML;


			// lo siguiente guarda los id, no sus valores.
		apunte_apunte=id;
		alert("apunte_apunte"+apunte_apunte);
		guardocuenta=editarcuentaID;
		guardodocumento=editardocumentoID;
		guardoidconcepto=editarid_conceptoID;
		guardoconcepto=editarconceptoID;
		guardodebeohaber=editardebe_o_haberID;
		guardoimportedebe=editarimporte_debeID;
		guardoimportehaber=editarimporte_haberID;

		var parent= document.querySelector("#" + apunteID);

		if (parent.querySelector("#" + editarapunteID) === null ) {


		document.getElementById(cuentaID).innerHTML = '<input type ="button" onclick="cambiarCuenta();" class= "btn btn-success"  id="'+editarcuentaID+'" value="'+cuentaid+'">';
		document.getElementById(documentoID).innerHTML = '<input type ="text" id="'+editardocumentoID+'" value="'+documentoid+'">';
		document.getElementById(id_conceptoID).innerHTML ='<input type ="button" onclick="cambiarIdConcepto();" class= "btn btn-success"  id="'+editarid_conceptoID+'"style="min-width:10px" value="'+id_conceptoid+'">';
		document.getElementById(conceptoID).innerHTML = '<input type ="text" id="'+editarconceptoID+'" value="'+conceptoid+'">';
		document.getElementById(debe_o_haberID).innerHTML = '<input type ="button" onclick="cambiarDebeHaber();" class= "btn btn-success"  id="'+editardebe_o_haberID+'" value="'+debe_o_haberid+'">';
		document.getElementById(importe_debeID).innerHTML = '<input type ="text" id="'+editarimporte_debeID+'" value="'+importe_debeid+'">';
		document.getElementById(importe_haberID).innerHTML = '<input type ="text" id="'+editarimporte_haberID+'" value="'+importe_haberid+'">';

		if(debe_o_haberid=="DEBE") {
			document.getElementById(editarimporte_haberID).disabled=true;
		}  else {
			document.getElementById(editarimporte_debeID).disabled=true;
		}

			// guarda los valores de los campos a editar:
		 v_cuentaid=document.getElementById(editarcuentaID).value;
		 alert("v_cuentaid"+v_cuentaid);
		 v_documentoid=document.getElementById(editardocumentoID).value;
		 v_id_conceptoid=document.getElementById(editarid_conceptoID).value;
		 v_conceptoid=document.getElementById(editarconceptoID).value;
		 v_debe_o_haberid=document.getElementById(editardebe_o_haberID).value;
		 v_importe_debeid=document.getElementById(editarimporte_debeID).value;
		 v_importe_haberid=document.getElementById(editarimporte_haberID).value;

		document.getElementById(borrar).disabled="true";
		document.getElementById(actualizar).style.display="block";
		}
	}
}

		function actualizarApunte() {

		 
		  alert(guardocuenta+" "+guardodocumento+" "+guardoidconcepto+" "+guardoconcepto+" "+guardodebeohaber+" "+guardoimportedebe+" "+guardoimportehaber);
		  var confirmar=confirm("Desea actualizar los posibles cambios");
		  if (!confirmar) {
		  	actualizando=false;
		  	Inicio();
		  } else {              //da igual que la cuenta vieja y nueva no sean la misma, a la vieja se le quita
		  						// y a la nueva se le suma. Si son la misma coinciden tambien las nomenclaturas.
		  						// Si ha habido cambio de importe o de Signo debe o haber, es lo mismo, se le restan
		  						// tanto el debe como el haber viejos y se le suman los nuevos. Bien debe o bien  // haber, uno de ellos sera cero.

	   		var apunte_usuario=user;
			var apunte_cuenta=document.getElementById(guardocuenta).value;
			var apunte_documento=document.getElementById(guardodocumento).value;
			var apunte_idconcepto=document.getElementById(guardoidconcepto).value;
			var apunte_concepto=document.getElementById(guardoconcepto).value;
			var apunte_debeohaber=document.getElementById(guardodebeohaber).value;
			var apunte_importedebe=document.getElementById(guardoimportedebe).value;
			var apunte_importehaber=document.getElementById(guardoimportehaber).value;
  				

	   		actualizoCuentaResto(v_cuentaid,v_importe_debeid,v_importe_haberid);
	   		actualizoCuentaSumo(apunte_cuenta, apunte_importedebe, apunte_importehaber);
	   		

	   		actualizando=false;


	   	// regrabamos el apunte.

	   	var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
								
			}
		}

	xmlhttp.open("GET", "../modelo/modelo_editar_apuntes.php?actualizarapunte="+"si"+"&usuario="+apunte_usuario+"&fecha="+apunte_fecha+"&asiento="+apunte_asiento+"&apunte="+apunte_apunte+"&cuenta="+apunte_cuenta+"&documento="+apunte_documento+"&idconcepto="+apunte_idconcepto+"&concepto="+apunte_concepto+"&debeohaber="+apunte_debeohaber+"&importedebe="+apunte_importedebe+"&importehaber="+apunte_importehaber, true);

		xmlhttp.send();
 
	   }
	   Inicio();
	}

	function actualizoCuentaResto(v_cuentaid,v_importe_debeid,v_importe_haber_id){

		alert("cuentaresto "+v_cuentaid);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
								
			}
		}

		xmlhttp.open("GET", "../modelo/modelo_editar_apuntes.php?cuentaresto="+"si"+"&cuenta="+v_cuentaid+"&importedebe="+v_importe_debeid+"&importehaber="+v_importe_haberid, true);
		xmlhttp.send();

	}

	function actualizoCuentaSumo(apunte_cuenta, apunte_importedebe, apunte_importehaber){

		alert("cuentasumo");

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
								
			}
		}

		xmlhttp.open("GET", "../modelo/modelo_editar_apuntes.php?cuentasumo="+"si"+"&cuenta="+apunte_cuenta+"&importedebe="+apunte_importedebe+"&importehaber="+apunte_importehaber, true);
		xmlhttp.send();

	}

	function cambiarIdConcepto(){

		
		document.getElementById("nuevaVentana").style.width="33%";

		overlay.style.opacity = .4;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
								
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_editar_apuntes.php?idconcepto="+"si", true);
		xmlhttp.send();

	}


	function cambiarCuenta() {

		
		document.getElementById("nuevaVentana").style.width="33%";

		overlay.style.opacity = .4;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				var mirar=xmlhttp.responseText;
				
				resultadoconsulta.innerHTML = xmlhttp.responseText;
								
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_editar_apuntes.php?cambiarcuenta="+"si", true);
		xmlhttp.send();

	}

	function validaCuentaNueva() {


		buscarCuentaB();


		if (cuentaposible=="si"){
			document.getElementById(guardocuenta).value = document.getElementById("nuevaCuentaId").value;
			cuentaposible="no";
			ejecutarNuevaVentana("noedicion");
		} else {
		 		alert("Debe confirmar existe la cuenta, pulse <'Busca Cuenta'>")
				}
	}
	function actualizarConceptos(id) {

		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		
		var debe_o_haberActualizado= document.getElementById("DEBE_O_HABER"+id+"-editar").value;
		var texto_fijoActualizado= document.getElementById("TEXTO_FIJO"+id+"-editar").value;
		

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

 				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
					actualizando=false;
 				
 				 	mostrarApuntes(pagina_actual);
			}

	}
		alert("id: "+id+" debe_haber: "+debe_o_haberActualizado+" texto fijo: "+texto_fijoActualizado);


		xmlhttp.open("GET", "../modelo/modelo_asientos.php?param1="+id+"&param2="+debe_o_haberActualizado+"&param3="+texto_fijoActualizado, true);
		xmlhttp.send();
	
}
 
		function borrarApunte(id) {


			var respuesta = confirm("Estas seguro de borrar este Concepto?");
			
			if (respuesta ===true ) {

				var xmlhttp;

				if(window.XMLHttpRequest) {
					
					xmlhttp = new XMLHttpRequest();

					} else {

					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

					}
				
				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				preparoMostrarApuntes();

				}
			}

				xmlhttp.open("GET", "../modelo/modelo_asientos.php?concepto_ideliminado="+id,true);
				xmlhttp.send();
		
		 }
	}


	var overlay = document.getElementById("overlay");
	var nuevaVentana= document.getElementById("nuevaVentana");

	function ejecutarNuevaVentana(sw){

		if (!sw) { sw="--"};

		overlay.style.opacity = .4;

		if (overlay.style.display == "block") {
			overlay.style.display="none";
			nuevaVentana.style.display="none";

		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		preparoMostrarCuentas(sw);
	}

	function ejecutarNuevaVentanaConcepto(sw){

		document.getElementById("nuevaVentana").style.width="70%";

		overlay.style.opacity = .4;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}


		consultarConceptosEdicion();

	}

	function ejecutarNuevaVentanaAlfa(sw){

		overlay.style.opacity = .2;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}
		preparoMostrarCuentasAlfa(sw);
		
	}
	function ejecutarNuevaVentanaB(){

		overlay.style.display="none";
		nuevaVentana.style.display="none";
		document.getElementById("nuevaVentana").style.width="70%";
		ejecutarNuevaVentana("edicion");


	}

	function ejecutarNuevaVentanaAlfaB(){

		overlay.style.display="none";
		nuevaVentana.style.display="none";
		document.getElementById("nuevaVentana").style.width="70%";
		ejecutarNuevaVentanaAlfa("edicion");
		
	}

	function agregarConcepto() {


	/*	var nuevoConcepto_Id=document.getElementById("nuevoConcepto_IdId").value;	
	 	var nuevoDebe_o_Haber=document.getElementById("nuevoDebe_o_HaberId").value;
	 	var nuevoTexto_Fijo=document.getElementById("nuevoTexto_FijoId").value;

		if (validarAgregar(nuevoConcepto_Id, nuevoDebe_o_Haber, nuevoTexto_Fijo)) { 
			*/

		overlay.style.display ="none";
		nuevaVentana.style.display = "none";

		var xmlhttp;

			if(window.XMLHttpRequest) {
					xmlhttp = new XMLHttpRequest();
					} else {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}

				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

				var meresponde=xmlhttp.responseText;
				var mensaje=meresponde;
				if (mensaje.includes("No ejecutado")) {
					alert(meresponde);
				}
 				preparoMostrarApuntes();

 				}
			}


 	/*	xmlhttp.open("GET", "../modelo/modelo_asientos.php?nuevoConcepto_Id="+nuevoConcepto_Id+"&nuevoDebe_o_Haber="+nuevoDebe_o_Haber+"&nuevoTexto_Fijo"+nuevoTexto_Fijo, true);
		xmlhttp.send();
	  } */
					 
/*	} */

}
		function validarAgregar(nuevoConcepto_Id, nuevoDebe_o_Haber, nuevoTexto_Fijo) {

			var mensajeFB=document.getElementById("feedback");

		/*	if(nuevaCuenta<100000000000 || nuevaCuenta>999999999999) {return false;}

			if(isNaN(nuevoGrado)) {
				mensajeFB.innerHTML='<button type = "button" value ="Grado no numerico" class = "btn btn-danger">Grado no numerico</button>';
				mensajeFB.style.margin="31%";
				return false;

			}   mensajeFB.innerHTML="";
				return true;   */
				return true;
		}

	
	function mostrarCuentas(pagina, param){

		pagina_actualc=pagina;

		num_paginasc= Math.ceil(num_registrosc/12);

		
		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML="<div> Consulta de Cuentas </div>";
				resultadoconsulta.innerHTML += xmlhttp.responseText;

			//	var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
			//enBoton.style.background="#679B9B";
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_consulta_plan.php?cuentas="+"cuentas"+"&pagina="+pagina+"&num_paginas="+num_paginasc+"&edicion="+param, true);
		xmlhttp.send();
	}


	function preparoMostrarCuentas(param){


			var xmlhttp;
			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {

 				num_registrosc = xmlhttp.responseText;

				mostrarCuentas(1,param);

				}
		}
		xmlhttp.open("GET", "../modelo/modelo_plan_cuentas.php?acontar="+"si", true);
		xmlhttp.send();
	}


	function mostrarCuentasAlfa(pagina, param){

		pagina_actualc=pagina;

		num_paginasc= Math.ceil(num_registrosc/12);


		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;

			//	var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
			//	enBoton.style.background="#679B9B";
			}
		}
		xmlhttp.open("GET", "../modelo/modelo_consulta_alfabetico.php?cuentas=" + "cuentas"+"&pagina="+pagina+"&num_paginas="+num_paginas+"&edicion="+param, true);
		xmlhttp.send();
	}


	function preparoMostrarCuentasAlfa(param){

			var xmlhttp;
			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {
 				num_registrosc = xmlhttp.responseText;
				mostrarCuentasAlfa(1,param);

				}
		}
		xmlhttp.open("GET", "../modelo/modelo_consulta_alfabetico.php?acontar="+"si", true);
		xmlhttp.send();
	}

	function seleccionarCuentaEdicion(id) {

			document.getElementById(guardocuenta).value = id;
			overlay.style.display="none";
			nuevaVentana.style.display="none";
			preparoMostrarCuentas("edicion");
		}

	function seleccionarCuenta(id) {

			document.getElementById("codcuenta").value=id;
			ejecutarNuevaVentana(1,"noedicion");
			buscaCuenta();
		}
		function seleccionarConcepto(id) {
			document.getElementById("concepto_numero").value=id;
			overlay.style.display="none";
			nuevaVentana.style.display="none";
			buscaConceptos();
		}

		function cambiarDebeHaber(){

			if (document.getElementById(guardodebeohaber).value=="DEBE") {

				document.getElementById(guardodebeohaber).value="HABER";
				var elimporte=document.getElementById(guardoimportedebe).value;
				document.getElementById(guardoimportedebe).value=0;
				document.getElementById(guardoimportedebe).disabled=true;
				document.getElementById(guardoimportehaber).value=elimporte;
				document.getElementById(guardoimportehaber).disabled=false;

			} else {

				document.getElementById(guardodebeohaber).value="DEBE";
				var elimporte=document.getElementById(guardoimportehaber).value;
				document.getElementById(guardoimportehaber).value=0;
				document.getElementById(guardoimportehaber).disabled=true;
				document.getElementById(guardoimportedebe).value=elimporte;
				document.getElementById(guardoimportedebe).disabled=false;
			}
		}

	function seleccionarConceptoEdicion(id,texto,dh) {

			var elimporte="";

			if  (v_importe_debeid==0) {
				 elimporte=v_importe_haberid;
				} 
				else { 
					elimporte=v_importe_debeid;
				}

			document.getElementById(guardoidconcepto).value=id;
			document.getElementById(guardoconcepto).value=texto;
			document.getElementById(guardodebeohaber).value=dh;

			if (dh=="DEBE") {
				document.getElementById(guardoimportehaber).value="0";
				document.getElementById(guardoimportedebe).value=elimporte;
				document.getElementById(guardoimportedebe).disabled=false;
				document.getElementById(guardoimportehaber).disabled=true;

			} else {
				document.getElementById(guardoimportedebe).value="0";
				document.getElementById(guardoimportehaber).value=elimporte;
				document.getElementById(guardoimportedebe).disabled=true;
				document.getElementById(guardoimportehaber).disabled=false;
			}

			overlay.style.display="none";
			nuevaVentana.style.display="none";
			preparoMostrarCuentas("edicion");
		}


	function consultarConceptos(){


		document.getElementById("nuevaVentana").style.width="70%";

		overlay.style.opacity = .4;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		preparoMostrarConceptos();
		
	}

		function consultarConceptosEdicion(){

		document.getElementById("nuevaVentana").style.width="70%";

		overlay.style.opacity = .4;
		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {
			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}
		preparoMostrarConceptosEdicion();
		
	}

	function mostrarConceptos(pagina) {


		pagina_actualConcepto=pagina;

		num_paginasConcepto= Math.ceil(num_registrosConcepto/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
				var enBoton=document.getElementById("boton"+pagina);
				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
			   //enBoton.style.background="#679B9B";
			}
		}
			xmlhttp.open("GET", "../modelo/modelo_consulta_concepto.php?conceptos="+"conceptos"+"&pagina="+pagina_actualConcepto+"&num_paginas="+num_paginasConcepto, true);
			xmlhttp.send();

	}


		function mostrarConceptosEdicion(pagina) {


		pagina_actualConcepto=pagina;

		num_paginasConcepto= Math.ceil(num_registrosConcepto/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultadoconsulta.innerHTML = xmlhttp.responseText;
				var enBoton=document.getElementById("boton"+pagina);
				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});
			   //enBoton.style.background="#679B9B";
			}
		}
			xmlhttp.open("GET", "../modelo/modelo_consulta_concepto_edicion.php?conceptos="+"conceptos"+"&pagina="+pagina_actualConcepto+"&num_paginas="+num_paginasConcepto, true);
			xmlhttp.send();

	}


	function preparoMostrarConceptos(){

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {
 				num_registrosConcepto = xmlhttp.responseText;
				mostrarConceptos(1);
			}
		}
			xmlhttp.open("GET", "../modelo/modelo_consulta_concepto.php?acontar="+"si", true);
			xmlhttp.send();
	}
	function preparoMostrarConceptosEdicion(){

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {
 				num_registrosConcepto = xmlhttp.responseText;
				mostrarConceptosEdicion(1);
			}
		}
			xmlhttp.open("GET", "../modelo/modelo_consulta_concepto_edicion.php?acontar="+"si", true);
			xmlhttp.send();
	}


</script>


