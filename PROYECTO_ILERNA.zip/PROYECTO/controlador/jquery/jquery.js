$(document).ready(function(){
   
  $(window).on('popstate', function(e) {

  	alert("donde vasss");
  	return false;

	})
} )
 

