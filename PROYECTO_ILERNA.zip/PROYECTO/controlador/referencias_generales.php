<div id="header-referencias">
		<div id="titulo-referencias">
			<div>Referencias Generales</div>
		</div>
</div>
<br><br>
<div id="overlay"></div>
<div id="nuevaVentana">
	<div id="box-header">Añadir Referencia</div>
	<button onmousedown="ejecutarNuevaVentana()" class="btn btn-primary" id="botonCerrar">
		<i class="fa  fa-door-open"></i>
	</button><br><br><br>
		<label style="margin-left:20%;">Fecha Contable: </label><input type="text" id ="nuevaFechaId"/><br><br>
		<label style="margin-left:20%;">Asiento Contable: </label><input type="" id="nuevoAsientoId"/><br><br><br>
	<button onmousedown="agregarReferencia()" style="margin-left:40%;" class="btn btn-success">Añadir Referencias</button><br>
</div>

<div id="wrapper">
	<div id="crud_gral"></div>
</div>

<script type="text/javascript">

	var resultado = document.getElementById("crud_gral");
	document.getElementById("nuevaVentana").style.height="250px";
	var num_registros;
	var num_paginas;
	var pagina_actual;
	var muestro_pagina;
 	var actualizando=false;
	

	function mostrarReferencias(pagina){

		pagina_actual=pagina;

		num_paginas= Math.ceil(num_registros/12);

		var xmlhttp;

		if(window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.onreadystatechange = function () {
			if (this.readyState === 4 && this.status === 200) {

				resultado.innerHTML = xmlhttp.responseText;

				var enBoton=document.getElementById("boton"+pagina);

				$(".botones").css({"background-color":'#AACFCF'});
				$(".botones").css({"color":'#fff'});

				enBoton.style.background="#679B9B";
			}
		}

		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?referencias=" + "referencias"+"&pagina="+pagina+"&num_paginas="+num_paginas, true);
		xmlhttp.send();
	}




	function preparoMostrarReferencias(){

			var xmlhttp;
			if(window.XMLHttpRequest) {
				xmlhttp = new XMLHttpRequest();
				} else {
				xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange = function () {
				if (this.readyState === 4 && this.status === 200) {

 				num_registros = xmlhttp.responseText;

				mostrarReferencias(1);

				}
		}

		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?acontar=" +"si", true);
		xmlhttp.send();

	}

	preparoMostrarReferencias();

	function retrocedoPagina(hastaDonde) {

		if (hastaDonde=="inicio"){

				mostrarReferencias(1);

		} else {

			if (pagina_actual > 1) {

				muestro_pagina = pagina_actual - 1;

				mostrarReferencias(muestro_pagina);
			}
		}
	}

	function avanzoPagina(hastaDonde, paginaFinal) {

		if (hastaDonde=="final") {

				mostrarReferencias(paginaFinal);
 
		} else {
 
		if (pagina_actual < num_paginas) {

			muestro_pagina = pagina_actual + 1;

			mostrarReferencias(muestro_pagina);

			}
		}

	}

	function editarReferencias(id) {

				if (!actualizando) {

		actualizando=true;


		var fechacontableID="FECHA_CONTABLE" + id;
		var asientocontableID="ASIENTO_CONTABLE" + id;
		var apuntecontableID="APUNTE_CONTABLE"+id;
		var borrar = "BORRAR" + id;
		var actualizar = "ACTUALIZAR" + id;
		var editarfechacontableID=fechacontableID+"-editar";
		var editarasientocontableID=asientocontableID+"-editar";
		var editarapuntecontableID=apuntecontableID+"-editar";

		var fechacontable=document.getElementById(fechacontableID).innerHTML; 
		var asientocontable=document.getElementById(asientocontableID).innerHTML;
		var apuntecontable=document.getElementById(apuntecontableID).innerHTML;

		var parent= document.querySelector("#" + fechacontableID);

		if (parent.querySelector("#" + editarfechacontableID) === null ) {

			document.getElementById(fechacontableID).innerHTML = '<input type ="text" id="'+editarfechacontableID+'" value="'+fechacontable+'">';

			document.getElementById(asientocontableID).innerHTML = '<input type ="text" id="'+editarasientocontableID+'" value="'+asientocontable+'">';

			document.getElementById(apuntecontableID).innerHTML = '<input type ="text" id="'+editarapuntecontableID+'" value="'+apuntecontable+'">';

			document.getElementById(borrar).disabled="true";
			document.getElementById(actualizar).style.display="block";
		}
	}
}

	function actualizarReferencias(id){


		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		var fechaActualizada= document.getElementById("FECHA_CONTABLE"+id+"-editar").value;
		var asientoActualizado= document.getElementById("ASIENTO_CONTABLE"+id+"-editar").value;
		var apunteActualizado= document.getElementById("APUNTE_CONTABLE"+id+"-editar").value;

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

 					actualizando=false;
 					
 					mostrarReferencias(pagina_actual);

 				 	/*preparoMostrarReferencias();*/
					
			}

	}

		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?param1="+id+"&param2="+fechaActualizada+"&param3="+asientoActualizado+"&param4="+apunteActualizado, true);
		xmlhttp.send();
}
		

		function borrarReferencia(id) {


			var respuesta = confirm("Estas seguro de borrar esta referencia?");
			
			if (respuesta ===true ) {

				var xmlhttp;

				if(window.XMLHttpRequest) {
					
					xmlhttp = new XMLHttpRequest();

					} else {

					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

					}
				
				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				preparoMostrarReferencias();

				}
			}

				xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?refeliminada="+id,true);
				xmlhttp.send();
		
		 }
	}


	var overlay = document.getElementById("overlay");
	var nuevaVentana= document.getElementById("nuevaVentana");

	function ejecutarNuevaVentana(){


		overlay.style.opacity = .7;

		if (overlay.style.display == "block") {

			overlay.style.display="none";
			nuevaVentana.style.display="none";
		} else {

			overlay.style.display="block";
			nuevaVentana.style.display="block";
		}

		document.getElementById("nuevaFechaId").value="";
		document.getElementById("nuevoAsientoId").value="";

	}

	function agregarReferencia() {

		overlay.style.display ="none";
		nuevaVentana.style.display = "none";

		var xmlhttp;

			if(window.XMLHttpRequest) {
					xmlhttp = new XMLHttpRequest();
					} else {
					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			}

		var nuevaFecha=document.getElementById("nuevaFechaId").value;	
		var nuevoAsiento=document.getElementById("nuevoAsientoId").value;




				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				preparoMostrarReferencias();

 				}
			}


 		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?nuevaF="+nuevaFecha+"&nuevoA="+nuevoAsiento, true);
		xmlhttp.send();
		
					 
	}



</script>


					