<div id="header-referencias">
		<div id="titulo-referencias">
			Referencias Generales
		</div>
</div>	
<div id="crud_ref_gral"></div>

<script type="text/javascript">
	
	var resultado = document.getElementById("crud_ref_gral");

	function mostrarReferencias(){

		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {

				resultado.innerHTML = xmlhttp.responseText;

			}

		}
		
		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?referencias=" + "referencias", true);
		xmlhttp.send();
	}
	

	mostrarReferencias();

	function editarReferencias(id) {

		var fechacontableID="FECHA_CONTABLE" + id;
		var asientocontableID="ASIENTO_CONTABLE" + id;
		var borrar = "BORRAR" + id;
		var actualizar = "ACTUALIZAR" + id;
		var editarfechacontableID=fechacontableID+"-editar";

		var fechacontable=document.getElementById(fechacontableID).innerHTML; 

		var parent= document.querySelector("#" + fechacontableID);

		if (parent.querySelector("#" + editarfechacontableID) === null ) {

			document.getElementById(fechacontableID).innerHTML = '<input type ="text" id="'+editarfechacontableID+'" value="'+fechacontable+'">';
			document.getElementById(borrar).disabled="true";
			document.getElementById(actualizar).style.display="block";
	}
}

	function actualizarReferencias(id){


		var xmlhttp;

		if(window.XMLHttpRequest) {

			xmlhttp = new XMLHttpRequest();

		} else {

			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}

		var fechaActualizada= document.getElementById("FECHA_CONTABLE"+id+"-editar").value;

		xmlhttp.onreadystatechange = function () {

			if (this.readyState === 4 && this.status === 200) {
 				
 				 	mostrarReferencias();

			}

	}

		xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?param1="+id+"&param2="+fechaActualizada, true);
		xmlhttp.send();
}

		function borrarReferencia(id) {


			var respuesta = confirm("Estas seguro de borrar esta referencia?");
			
			if (respuesta ===true ) {

				var xmlhttp;

				if(window.XMLHttpRequest) {
					
					xmlhttp = new XMLHttpRequest();

					} else {

					xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");

					}
				
				xmlhttp.onreadystatechange = function () {

				if (this.readyState === 4 && this.status === 200) {

 				mostrarReferencias();

				}
			}

				xmlhttp.open("GET", "../modelo/modelo_ref_gral.php?param3="+id,true);
				xmlhttp.send();
		
		 }
	}

	 



</script>

					