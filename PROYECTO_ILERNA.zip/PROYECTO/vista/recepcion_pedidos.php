<div id="header-recepcion-pedidos">
		
			<ul class="header-recepcion-pedidos-nav">
				<li><a href="">Registro Pedidos</a></li>
				<li><a href="">Pendientes</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion4').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Recepción Pedidos ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
