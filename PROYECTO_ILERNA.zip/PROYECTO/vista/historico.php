<div id="header-historico">
		
			<ul class="header-historico-nav">
				<li><a href="">Por Producto</a></li>
				<li><a href="">Por Almacén</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Historico de Productos ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
