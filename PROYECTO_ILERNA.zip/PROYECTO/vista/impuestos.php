<div id="header-impuestos">
		
			<ul class="header-impuestos-nav">
				<li><a href=""> Iva / Igic </a></li>
				<li><a href=""> Modelo 347 </a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Impuestos ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
