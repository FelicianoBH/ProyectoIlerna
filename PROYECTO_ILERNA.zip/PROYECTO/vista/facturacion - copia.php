<div id="header-ofertas">
		
			<ul class="header-ofertas-nav">
				<li><a href="">Pedidos</a></li>
				<li><a href="">Albaranes</a></li>
				<li><a href="">Directa</a></li>
				<li><a href="">Entregas</a></li>
				<li><a href="">Fac Diferido</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Facturación ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
