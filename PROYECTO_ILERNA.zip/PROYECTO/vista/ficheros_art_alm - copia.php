<div id="header-ficheros-art-alm">
		
			<ul class="header-ficheros-art-alm-nav">
				<li><a href="">Amacenes</a></li>
				<li><a href="">Artículos</a></li>
			</ul>
</div>

<script type="text/javascript">
	
	document.getElementById('lateral-opcion3').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Artículos/Almacén";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
