<div id="header-provedores">
		
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion4').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Provedores ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
