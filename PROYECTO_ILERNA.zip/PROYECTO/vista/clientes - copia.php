<div id="header-clientes">
		
			<ul class="header-clientes-nav">
				<li><a href="">Pedidos</a>
				</li>
				<li><a href="">Entregas</a>
				</li>
				<li><a href="">Facturacion</a>
				</li>
				<li><a href="">Devoluciones</a>
				</li>
				<li><a href="">Post-Venta</a>
					<ul class="sublista">
						<li><a href="">Entregas Pendientes</a></li>
						<li><a href="">Reclamaciones</a></li>
						<li><a href="">Garantía</a></li>
					</ul>
				</li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Clientes";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>



