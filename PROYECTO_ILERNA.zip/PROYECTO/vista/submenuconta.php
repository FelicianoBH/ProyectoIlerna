
	<div id="header-conta">
		
			<ul class="header-conta-nav">
				<li><a href="">Plan de Cuentas</a>
					<ul>
						<li><a href="">Consulta Plan</a></li>
						<li><a href="">Mantenimiento Cuentas</a></li>
					</ul>
				</li>
				<li><a href=""> Libro de Diario </a>
					<ul>
						<li><a href="">Introducción Apuntes </a></li>
						<li><a href="">Asientos Autmáticos</a></li>
						<li><a href="">Listado Diario</a></li>
						</li>
					</ul>
				</li>
				<li><a href="">Listados/Consultas</a>
					<ul>
						<li><a href="">Extractos Contables</a></li>
						<li><a href="">Conciliacion apuntes</a></li>
						<li><a href="">Balance Sumas y Saldos</a></li>
					</ul>
				</li>
			</ul>


	</div>
	