<div id="header-balances">
		
			<ul class="header-balances-nav">
				<li><a href="">Sumas y Saldos</a></li>
				<li><a href="">Situación</a></li>
				<li><a href="">Explotación</a></li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion5').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Balances Contables";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
