<div id="header-historico-ventas">
		
			<ul class="header-historico-ventas-nav">
				<li><a href="">Por Cliente</a></li>
				<li><a href="">Por Producto</a></li>
				<li><a href="">Por Almacén</a></li>

			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Historico de Ventas ";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
