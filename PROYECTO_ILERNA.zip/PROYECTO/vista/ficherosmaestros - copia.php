<div id="header-ficheros">
		
			<ul class="header-ficheros-nav">
				<li><a href="gestion.php?op=111">Referencias Generales</a>
				</li>
				<li><a href="gestion.php?op=112">Plan de Cuentas</a>
				</li>
				<li><a href="gestion.php?op=113">Sedes</a>
				</li>
				<li><a href="gestion.php?op=114">Conceptos Contables</a>
				</li>
			</ul>
</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion1').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+="  Ficheros Maestros";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
	