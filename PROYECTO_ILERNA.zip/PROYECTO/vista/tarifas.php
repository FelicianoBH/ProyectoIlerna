<div id="header-tarifas">
		
			<ul class="header-tarifas-nav">
				<li><a href="">Confección</a>
				</li>
				<li><a href="">Listados Tarifas </a>
				</li>
			</ul>
	</div>
<script type="text/javascript">
	
	document.getElementById('lateral-opcion2').style.backgroundColor='#0A4A45';
	document.getElementById('screen').innerHTML+=" Tarifas";
	document.getElementById('screen').style.backgroundColor="#0A4A45";
	document.getElementById('screen').style.color="#fff";
	
</script>
	