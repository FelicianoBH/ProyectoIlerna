<?php 
	require "conexion.php";
 

	$sedes="";
	$filtraid_sede="";
	$filtranombre="";
	$filtradescripcion="";
	$filtradirecion="";
	$filtraid_responsable="";

	$id_sedeActualizada="";
	$nombre_Actualizado="";
	$descripcionActualizada="";
	$direccionActualizada="";
	$id_responsableActualizada="";
	
	$id_sedeEliminada="";
	$nuevaId_Sede="";
	$nuevoNombre="";
	$nuevaDescripcion="";
	$nuevaDireccion="";
	$nuevaId_Responsable="";
	$acontar="no";
	$pagina=0;
	$num_paginas=0;
	$desde=0;
	$fechaHoy=0;

	if (isset($_GET['sedes'])) {
		$sedes = $_GET['sedes'];
		$pagina=$_GET['pagina'];
		$num_paginas=$_GET['num_paginas'];
		}

	if (isset($_GET['acontar'])) {
		$acontar="si";
		} else {
			$acontar="no";
		}
	
	
	if (isset($_GET['nuevaId_Sede'])) {

		$nuevaId_Sede=$_GET['nuevaId_Sede'];
		$nuevoNombre=$_GET['nuevoNombre'];
		$nuevaDescripcion=$_GET['nuevaDescripcion'];
		$nuevaDireccion=$_GET['nuevaDireccion'];
		$nuevaId_Responsable=$_GET['nuevaId_Responsable'];

	}



	if (isset($_GET['param1'])) {
		$id_sedeActualizada = $_GET['param1'];
		}
	if (isset($_GET['param2'])){
		$nombreActualizado = $_GET['param2'];
		}
	if (isset($_GET['param3'])) {
		$descripcionActualizada = $_GET['param3'];
		}
	if (isset($_GET['param4'])){
		$direccionActualizada = $_GET['param4'];
		}
	if (isset($_GET['param5'])){
		$id_responsableActualizada = $_GET['param5'];
		}

	if (isset($_GET['id_sedeeliminada'])) {
		$id_sedeEliminada=$_GET['id_sedeeliminada'];
	 	}


	$id_sede = "ID_SEDE";
	$nombre = "NOMBRE";
	$descripcion = "DESCRIPCION";
	$direccion="DIRECCION";
	$id_responsable="ID_RESPONSABLE";

	$actualizar ="ACTUALIZAR";
	$borrar = "BORRAR";
	$tamanio=12;




	
	if ($acontar=="si") {

		$resultado = mysqli_query($con, "SELECT * FROM sedes");
		$num_filas = mysqli_num_rows($resultado);
		echo $num_filas;

	}


	if($sedes==="sedes") {

			
			$desde=(($pagina-1)*$tamanio);

		 	$resultado = mysqli_query($con, "SELECT * FROM sedes LIMIT $desde,$tamanio");


			$table = '<div class = "container">';
			$table .=  '<table class = "table table-striped table-bordered table-hover table-condensed table-responsive">';
			$table .= '<tr>';
			$table .= '<th class="col-sm-2">ID Sede</th>';
			$table .= '<th class="col-sm-12">Nombre</th>';
			$table .= '<th class="col-sm-10">Descripcion</th>';
			$table .= '<th class="col-sm-10">Direccion</th>';
			$table .= '<th class="col-sm-2">ID Responsable</th>';
			$table .= '<th class="col-sm-2">Modificar</th>';
			$table .= '<th class="col-sm-2">Eliminar</th>';
			$table .= '</tr>';


			while ($fila = mysqli_fetch_assoc($resultado)) {

			$table .= '<tr>';
			$table .= '<td id="'.$id_sede.$fila['ID_SEDE'].'">' . $fila['ID_SEDE'] . '</td>';
			$table .= '<td id="'.$nombre.$fila['ID_SEDE'].'">' . $fila['NOMBRE'] . '</td>';
			$table .= '<td id="'.$descripcion.$fila['ID_SEDE'].'">' . $fila['DESCRIPCION'] . '</td>';
			$table .= '<td id="'.$direccion.$fila['ID_SEDE'].'">' . $fila['DIRECCION'] . '</td>';
			$table .= '<td id="'.$id_responsable.$fila['ID_SEDE'].'">' . $fila['ID_RESPONSABLE'] . '</td>';

			$table .= '<td><input id="'.$fila['ID_SEDE'].'" onclick="editarSedes(this.id)" type = "button" value ="Editar" class = "btn btn-success"></td>';
			$table .= '<td><input  id="'.$borrar.$fila['ID_SEDE'].'" onclick="borrarSede('.$fila['ID_SEDE'].')"  type = "button" value ="Borrar" class = "btn btn-danger"></td>';

			$table .= '<td><input id="'.$actualizar.$fila['ID_SEDE'].'" onclick = "actualizarSedes('.$fila['ID_SEDE'].')" type = "button" value ="Actualizar" class = "btn btn-primary" style="display:none;"></td>';
			$table .= '</tr>';
			}

		$table.= '</table>';
		$table.= '<button onclick="ejecutarNuevaVentana()" class="btn btn-primary">Agregar Sede</button>';
		$table.="<br>";
		$table.="<h4>Mostrar Página:</h4>";
		$table.="<button class='botones' onclick="."'retrocedoPagina()'>"."<"."</button>";

		for ($i=0; $i<$num_paginas;$i++) {

			$table.="<button class='botones' onclick="."mostrarSedes(".($i+1).")"." id="."boton".($i+1).">".($i+1)."</button>";
		
			} 

		$table.="<button  class='botones' onclick="."'avanzoPagina()'>".">"."</button>";
		$table.= "</div>";
		echo $table;
		mysqli_close($con);
	} 



		if(!empty($id_sedeActualizada)) {

		$filtraid_sede=mysqli_real_escape_string($con, $id_sedeActualizada);
		$filtranombre=mysqli_real_escape_string($con, $nombreActualizado);
		$filtradescripcion=mysqli_real_escape_string($con, $descripcionActualizada);
		$filtradireccion=mysqli_real_escape_string($con, $direccionActualizada);
		$filtraid_responsable=mysqli_real_escape_string($con, $id_responsableActualizada);

	
		$query="UPDATE sedes SET NOMBRE = '$filtranombre', DESCRIPCION = '$filtradescripcion', DIRECCION = '$filtradireccion', ID_RESPONSABLE='$filtraid_responsable' WHERE  ID_SEDE =  $filtraid_sede";
		 

		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No correcto". mysqli_error($con);
		}
		mysqli_close($con); 
	}
		
		
		if(!empty($id_sedeEliminada)){

		$id_sede=mysqli_real_escape_string($con, $id_sedeEliminada);
		$resultado=mysqli_query($con, "DELETE FROM sedes WHERE ID_SEDE = $id_sede");
		mysqli_close($con);

		} 
		
		if(!empty($nuevaId_Sede)) {


		$query="INSERT INTO sedes (ID_SEDE, NOMBRE, DESCRIPCION, DIRECCION, ID_RESPONSABLE) VALUES ('$nuevaId_Sede', '$nuevoNombre', '$nuevaDescripcion', '$nuevaDireccion', '$nuevaId_Responsable')";

		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No ejecutado".mysqli_error($con);
		}

		mysqli_close($con);
	} 

?>


