<?php 
	session_start();

	require "conexion.php";
  
	$apuntes="";
	$conceptos="";
	$filtraconcepto_id="";
	$filtradebe_o_haber="";
	$filtratexto_fijo=""; 
	$filtraid_usuario=""; 
	$filtradebehaber="";
	$filtraimporte="";

 
	$concepto_idActualizado="";
	$debe_o_haberActualizado="";
	$texto_fijoActualizado="";

	$codigo_cuenta="";
	
	$conceptoIdEliminado="";
	$nuevoConcepto_Id="";
	$nuevoDebe_o_Haber="";
	$nuevoTexto_Fijo="";
	$acontar="no";
	$acontarapuntes="no";
	$pagina=0;
	$num_paginas=0;
	$desde=0;
	$leer_ref="";
	$sesion="";
	$concepto_numero=0;
	$agrabar_importe=0;
	$agrabar_debehaber="";
	$agrabar_ref="";

	$agrabar_apu="";
	$agrabar_cta="";
	$agrabar_fecha="";
	$agrabar_asiento="";
	$agrabar_apunte=0;
	$agrabar_cuenta="";
	$agrabar_debehaber="";
	$agrabar_documento="";
	$agrabar_importe="";
	$agrabar_concepto_numero="";
	$agrabar_concepto_texto="";
	$cambiarcuenta="";

	$id_usuario=$_SESSION["id_usuario"];


	if (isset($_GET['cambiarcuenta'])) {

		$cambiarcuenta=$_GET['cambiarcuenta'];

	}

	if (isset($_GET['agrabar_apu'])) {

		$agrabar_apu=$_GET['agrabar_apu'];
		$agrabar_fecha=$_GET['agrabar_fecha'];
		$agrabar_asiento=$_GET['agrabar_asiento'];
		$agrabar_apunte=$_GET['agrabar_apunte'];
		$agrabar_cuenta=$_GET['agrabar_cuenta'];
		$agrabar_debehaber=$_GET['agrabar_debehaber'];
		$agrabar_documento=$_GET['agrabar_documento'];
		$agrabar_concepto_numero=$_GET['agrabar_concepto_numero'];
		$agrabar_concepto_texto=$_GET['agrabar_concepto_texto'];
		$agrabar_importe=$_GET['agrabar_importe'];

	}

	if (isset($_GET['agrabar_cta'])) {

		$agrabar_cta=$_GET['agrabar_cta'];
		$agrabar_cuenta=$_GET['agrabar_cuenta'];
		$agrabar_debehaber=$_GET['agrabar_debehaber'];
		$agrabar_importe=$_GET['agrabar_importe'];

	}

	if (isset($_GET['agrabar_ref'])) {

		$agrabar_ref=$_GET['agrabar_ref'];
		$agrabar_importe=$_GET['agrabar_importe'];
		$agrabar_debehaber=$_GET['agrabar_debehaber'];
	}

	if (isset($_GET['leer_ref'])) {

		$leer_ref=$_GET['leer_ref'];

		}

	if (isset($_GET['concepto_numero'])){

		$concepto_numero=$_GET['concepto_numero'];
	}

	if (isset($_GET['cuenta'])){

		$codigo_cuenta=$_GET['cuenta'];

		}

	if (isset($_GET['apuntes'])) {
		$apuntes = $_GET['apuntes'];
		$pagina=$_GET['pagina'];
		$num_paginas=$_GET['num_paginas'];
		}

	if (isset($_GET['acontar'])) {
		$acontar="si";
		} else {
			$acontar="no";
		}

	if (isset($_GET['acontarapuntes'])) {
		$acontarapuntes="si";
		} else {
			$acontarapuntes="no";
		}
	
	
	if (isset($_GET['nuevoConcepto_Id'])) {

		$nuevoConcepto_Id=$_GET['nuevoConcepto_Id'];
		$nuevoDebe_o_Haber=$_GET['nuevoDebe_o_Haber'];
		$nuevoTexto_Fijo=$_GET['nuevoTexto_Fijo'];

	}

	if (isset($_GET['param1'])) {
		$concepto_IdActualizado = $_GET['param1'];
		}
	if (isset($_GET['param2'])){
		$debe_o_haberActualizado = $_GET['param2'];
		}
	if (isset($_GET['param3'])) {
		$texto_fijoActualizado = $_GET['param3'];
		}

	if (isset($_GET['concepto_ideliminado'])) {
		$concepto_IdEliminado = $_GET['concepto_ideliminado'];
		}

	$concepto_id = "CONCEPTO_ID";
	$debe_o_haber = "DEBE_HABER";
	$texto_fijo = "TEXTO_FIJO";

	$actualizar ="ACTUALIZAR";
	$borrar = "BORRAR";
	$tamanio=9;

	$fecha="";
	$asiento="";
	$apunte="APUNTE";
	$documento="DOCUMENTO";
	$cuenta="CUENTA";
	$id_concepto="ID_CONCEPTO";
	$concepto="CONCEPTO";
	$importedebe="IMPORTED";
	$importehaber="IMPORTEH";
	$cero="0";
	



	if ($acontarapuntes=="si") {

		$resultado = mysqli_query($con, "SELECT * FROM apuntes WHERE USUARIO = '$id_usuario' ");
		$num_filas = mysqli_num_rows($resultado);
		echo $num_filas;
	}

	if ($acontar=="si") {

		$resultado = mysqli_query($con, "SELECT * FROM conceptos");
		$num_filas = mysqli_num_rows($resultado);
		echo "hay te van:".$num_filas;
	}


	if($apuntes==="apuntes") {
			
			$desde=(($pagina-1)*$tamanio);

		 	$resultado = mysqli_query($con, "SELECT * FROM apuntes WHERE USUARIO = '$id_usuario' LIMIT $desde,$tamanio");

			
			$table = '<div class = "container">';
			$table .=  '<table class = "table table-striped table-bordered table-hover table-condensed table-responsive">';
			$table .= '<tr>';
			$table .= '<th class="col-sm-1">Apunte</th>';
			$table .= '<th class="col-sm-1">Cuenta</th>';
			$table .= '<th class="col-sm-1">Documento</th>';
			$table .= '<th class="col-sm-1">Id Concepto</th>';
			$table .= '<th class="col-sm-10">Concepto</th>';
			$table .= '<th class="col-sm-2">Debe/Haber</th>';
			$table .= '<th class="col-sm-2">Importe Debe</th>';
			$table .= '<th class="col-sm-2">Importe Haber</th>';
			$table .= '</tr>';

 
			while ($fila = mysqli_fetch_assoc($resultado)) {

			$table .= '<tr>';
			$table .= '<td id="'.$apunte.$fila['APUNTE'].'">' . $fila['APUNTE'] . '</td>';
			$table .= '<td id="'.$cuenta.$fila['APUNTE'].'">' . $fila['CUENTA'] . '</td>';
			$table .= '<td id="'.$documento.$fila['APUNTE'].'">' . $fila['DOCUMENTO'] . '</td>';
			$table .= '<td id="'.$id_concepto.$fila['APUNTE'].'">' . $fila['ID_CONCEPTO'] . '</td>';
			$table .= '<td id="'.$concepto.$fila['APUNTE'].'">' . $fila['CONCEPTO'] . '</td>';
			$table .= '<td id="'.$debe_o_haber.$fila['APUNTE'].'">' . $fila['DEBE_HABER'] . '</td>';

			if ($fila['DEBE_HABER']=="DEBE"){
				$table .= '<td id="'.$importedebe.$fila['APUNTE'].'">' . $fila['IMPORTE'] . '</td>';
				$table .= '<td id="'.$importehaber.$fila['APUNTE'].'">' . $cero . '</td>';
			} else {
					$table .= '<td id="'.$importedebe.$fila['APUNTE'].'">' . $cero . '</td>';
					$table .= '<td id="'.$importehaber.$fila['APUNTE'].'">' . $fila['IMPORTE'] . '</td>';
					}

			$table .= '<td><input id="'.$fila['APUNTE'].'" onclick="editarApunte(this.id)" type = "button" value ="Editar" class = "btn btn-success"></td>';
			$table .= '<td><input  id="'.$borrar.$fila['APUNTE'].'" onclick="borrarApunte('.$fila['APUNTE'].')"  type = "button" value ="Borrar" class = "btn btn-danger"></td>';
			$texto="'";
			$table .= '<td><input id="'.$actualizar.$fila['APUNTE'].'" onclick = "actualizarApunte('.$texto.$fila['APUNTE'].$texto.')" type = "button" value ="Actualiza / Abandona" class = "btn btn-primary" style="display:none;"></td>'; 
 
			$table .= '</tr>';
			}
		$table.= '</table>';
		$table.="<h4>Mostrar Página:</h4>";
		$table.="<button class='botones' onclick="."'retrocedoPagina()'>"."<"."</button>";

		
		$table.="<button  class='botones' onclick="."'avanzoPagina()'>".">"."</button>";
		$table.= "</div>";
		echo $table;
		mysqli_close($con);
	} 

	if ($agrabar_ref=="si") {


		if ($agrabar_debehaber=="DEBE") {
			
			$query="UPDATE referencias SET DEBE_ASIENTO_ACTUAL=DEBE_ASIENTO_ACTUAL+'$agrabar_importe', APUNTE_CONTABLE=APUNTE_CONTABLE+'1' WHERE ID_USUARIO='$id_usuario'";

			} else {

				$query="UPDATE referencias SET HABER_ASIENTO_ACTUAL=(HABER_ASIENTO_ACTUAL+'$agrabar_importe'), APUNTE_CONTABLE=(APUNTE_CONTABLE+'1') WHERE ID_USUARIO='$id_usuario'";
			}
		
		$resultado=mysqli_query($con, $query);
		if (!$resultado) {
			echo "Error";
			}
		mysqli_close($con); 

	}

	if ($agrabar_cta=="si") {

		if ($agrabar_debehaber=="DEBE") {
			
			$query="UPDATE cuentas SET DEBE_ANIO = DEBE_ANIO +'$agrabar_importe'  WHERE CODIGO_CUENTA='$agrabar_cuenta'";

			} else {

				$query="UPDATE cuentas SET HABER_ANIO=HABER_ANIO+'$agrabar_importe'  WHERE CODIGO_CUENTA='$agrabar_cuenta'";
			}
		
		$resultado=mysqli_query($con, $query);

		if (!$resultado) {

			echo "Error ". $agrabar_debehaber." ".$agrabar_cuenta." ".$agrabar_importe;
			}

		mysqli_close($con); 

	}
	
		
		if(!empty($concepto_IdEliminado)){

		$concepto_id=mysqli_real_escape_string($con, $concepto_IdEliminado);
		$resultado=mysqli_query($con, "DELETE FROM conceptos WHERE CONCEPTO_ID = $concepto_id");

		mysqli_close($con);

	}


		if(!empty($leer_ref)) {

			$user=$_SESSION["usuario"];
			


			$query="SELECT FECHA_CONTABLE, ASIENTO_CONTABLE, APUNTE_CONTABLE FROM referencias WHERE ID_USUARIO = '$id_usuario'";


			$resultado = mysqli_query($con, $query);

			if (mysqli_num_rows($resultado)> 0) {

			$fila = mysqli_fetch_assoc($resultado);

			$datos_ref= new stdClass();
			$datos_ref->fechaRef=$fila['FECHA_CONTABLE'];
			$datos_ref->asientoRef=$fila['ASIENTO_CONTABLE'];
			$datos_ref->apunteRef=$fila['APUNTE_CONTABLE'];
			$json=json_encode($datos_ref);
			echo $json;
			} 
		} 

		if(!empty($concepto_numero)){

			$query="SELECT DEBE_O_HABER, TEXTO_FIJO FROM conceptos WHERE CONCEPTO_ID='$concepto_numero'";

			$resultado =mysqli_query($con, $query);

			if (mysqli_num_rows($resultado)> 0) {

			$fila = mysqli_fetch_assoc($resultado);

			$datos_concepto = new stdClass();

			$datos_concepto->concepto=$fila['TEXTO_FIJO'];
			$datos_concepto->debehaber=$fila['DEBE_O_HABER'];
			$json=json_encode($datos_concepto);
			echo $json;

			} else { $datos_concepto = new stdClass();

					$datos_concepto->concepto="CONCEPTO INEXISTENTE";
					$datos_concepto->debehaber="_";
					$json=json_encode($datos_concepto);
					echo $json;
					}	
		}

		if(!empty($codigo_cuenta)) {

			$query="SELECT TITULO FROM cuentas WHERE CODIGO_CUENTA = '$codigo_cuenta'";

			$resultado = mysqli_query($con, $query);

			if (mysqli_num_rows($resultado) > 0) {

			$fila = mysqli_fetch_assoc($resultado);

			echo $fila['TITULO'];

			}  else echo "INEXISTENTE";
		}  

		if(!empty($concepto_IdActualizado)) {

		$filtraconcepto_id=mysqli_real_escape_string($con, $concepto_IdActualizado);
		$filtradebe_o_haber=mysqli_real_escape_string($con, $debe_o_haberActualizado);
		$filtratexto_fijo=mysqli_real_escape_string($con, $texto_fijoActualizado);

	
		$query="UPDATE conceptos SET DEBE_O_HABER = '$filtradebe_o_haber', TEXTO_FIJO = '$filtratexto_fijo' WHERE  'CONCEPTO_ID' =  $filtraconcepto_id";
		 
		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No correcto". mysqli_error($con);
		}
		mysqli_close($con); 
	}
		

	if($agrabar_apu=="si") {

		$id_usuario=$_SESSION["id_usuario"];
		$fecha_hoy=date("Y-m-d");
		$query="INSERT INTO apuntes (USUARIO, FECHA, ASIENTO, APUNTE, DOCUMENTO, ID_CONCEPTO, CONCEPTO, DEBE_HABER, IMPORTE, CUENTA,FECHA_REAL) VALUES ('$id_usuario', '$agrabar_fecha', '$agrabar_asiento','$agrabar_apunte','$agrabar_documento','$agrabar_concepto_numero','$agrabar_concepto_texto','$agrabar_debehaber','$agrabar_importe','$agrabar_cuenta','$fecha_hoy')";

		$lista=new stdClass();
		$lista->cero=$id_usuario;
		$lista->uno=$agrabar_apu;
		$lista->dos=$agrabar_fecha;
		$lista->tres=$agrabar_asiento;
		$lista->cuatro=$agrabar_apunte;
		$lista->cinco=$agrabar_cuenta;
		$lista->seis=$agrabar_debehaber;
		$lista->siete=$agrabar_documento;
		$lista->ocho=$agrabar_concepto_numero;
		$lista->nueve=$agrabar_concepto_texto;
		$lista->diez=$agrabar_importe;
		$lista->once=$fecha_hoy;
		$json=json_encode($lista);

		if (mysqli_query($con, $query)) {
			echo "correcto -> ".$json; 
		} else { 
			echo "Error al grabar el Diario".mysqli_error($con);
		}

		mysqli_close($con);
	} 


	
?>



