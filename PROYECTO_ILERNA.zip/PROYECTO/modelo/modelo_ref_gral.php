<?php 
	require "conexion.php";
 

	$referencias="";
	$fechaActualizada="";
	$fechaIdActualizada="";
	$referenciaIDEliminada="";
	$nuevaFecha="";
	$nuevoAsiento="";
	$acontar="no";
	$pagina=0;
	$num_paginas=0;
	$desde=0;


	if (isset($_GET['referencias'])) {
		$referencias = $_GET['referencias'];
		$pagina=$_GET['pagina'];
		$num_paginas=$_GET['num_paginas'];
		}
	
	if (!isset($_GET['referencias']) && isset($_GET['nuevaF'])) {

		$nuevaFecha=$_GET['nuevaF'];
		$nuevoAsiento=$_GET['nuevoA'];
	}

	if (isset($_GET['param1'])) {
		$referenciaIdActualizada = $_GET['param1'];
		}
	if (isset($_GET['param2'])){
		$fechaActualizada = $_GET['param2'];
		}
	if (isset($_GET['param3'])) {
		$asientoActualizado=$_GET['param3'];
	 	}
	if (isset($_GET['param4'])) {
		$apunteActualizado=$_GET['param4'];
	 	}

	if (isset($_GET['refeliminada'])){
		$referenciaIDEliminada=$_GET['refeliminada'];
	}

	if (isset($_GET['acontar'])) {

		$acontar="si";
		} else {
			$acontar="no";
		}

	$id_usuario = "ID_USUARIO";
	$fecha_contable = "FECHA_CONTABLE";
	$asiento_contable = "ASIENTO_CONTABLE";
	$apunte_contable="APUNTE_CONTABLE";
	$actualizar ="ACTUALIZAR";
	$borrar = "BORRAR";
	$tamanio=12;




	
	if ($acontar=="si") {

		$resultado = mysqli_query($con, "SELECT * FROM referencias");
		$num_filas = mysqli_num_rows($resultado);
		echo $num_filas;

	}


	if($referencias==="referencias") {

			
			$desde=(($pagina-1)*$tamanio);

		 	$resultado = mysqli_query($con, "SELECT * FROM referencias LIMIT $desde,$tamanio");


			$table = '<div class = "container">';
			$table .=  '<table class = "table table-striped table-bordered table-hover table-condensed table-responsive">';
			$table .= '<tr>';
			$table .= '<th class="col-sm-2">Usuario Id</th>';
			$table .= '<th class="col-sm-2">Fecha Contable</th>';
			$table .= '<th class="col-sm-2">Asiento</th>';	
			$table .= '<th class="col-sm-2">Apunte</th>';
			$table .= '<th class="col-sm-1">Modificar</th>';
			$table .= '<th class="col-sm-1">Eliminar</th>';
			$table .= '</tr>';


			while ($fila = mysqli_fetch_assoc($resultado)) {

				$table .= '<tr>';
				$table .= '<td>' . $fila['ID_USUARIO'] . '</td>';
				$table .= '<td id="'.$fecha_contable.$fila['ID_USUARIO'].'">' . $fila['FECHA_CONTABLE'] . '</td>';
				$table .= '<td id="'.$asiento_contable.$fila['ID_USUARIO'].'">' . $fila['ASIENTO_CONTABLE'] . '</td>';
				$table .= '<td id="'.$apunte_contable.$fila['ID_USUARIO'].'">' . $fila['APUNTE_CONTABLE'] . '</td>';
				$table .= '<td><input id="'.$fila['ID_USUARIO'].'" onclick="editarReferencias(this.id)" type = "button" value ="Editar" class = "btn btn-success"></td>';

				$table .= '<td><input  id="'.$borrar.$fila['ID_USUARIO'].'" onclick="borrarReferencia('.$fila['ID_USUARIO'].')"  type = "button" value ="Borrar" class = "btn btn-danger"></td>';

/*				$table .= '<td><input id="'.$actualizar.$fila['ID_USUARIO'].'" onclick = "actualizarReferencias('.$fila['ID_USUARIO'].')" type = "button" value ="Actualizar" class = "btn btn-primary" style="display:none;"></td>';*/

				$texto="'";
  				$table .= '<td><input id="'.$actualizar.$fila['ID_USUARIO'].'" onclick = "actualizarReferencias('.$texto.$fila['ID_USUARIO'].$texto.')" type = "button" value ="Actualizar" class = "btn btn-primary" style="display:none;"></td>'; 
 

				$table .= '</tr>';
			}

		$table.= '</table>';
		$table.= '<button onclick="ejecutarNuevaVentana()" class="btn btn-primary">Agregar Referencias</button>';
		$table.="<br>";
		$table.="<h4>Mostrar Página:</h4>";


		$table.="<button class='botones' onclick="."retrocedoPagina(".'"inicio"'.")"." id=".">".'<<'."</button>";
		$table.="<button class='botones' onclick="."'retrocedoPagina()'>"."<"."</button>";




	/**	$table.="<button class='botones' onclick="."'retrocedoPagina()'>"."<"."</button>"; */

			for ($i=0; $i<$num_paginas;$i++) {

			$table.="<button class='botones' onclick="."mostrarReferencias(".($i+1).")"." id="."boton".($i+1).">".($i+1)."</button>";
		
			} 

	/*	$table.="<button  class='botones' onclick="."'avanzoPagina()'>".">"."</button>"; */

			$table.="<button  class='botones' onclick="."'avanzoPagina()'>".">"."</button>";
			$table.="<button class='botones' onclick="."avanzoPagina(".'"final"' .','.$num_paginas.")"." id=".">".'>>'."</button>";

		$table.= "</div>";
		echo $table;
		mysqli_close($con);
	} 



		if(!empty($referenciaIdActualizada)) {

		$referencia=mysqli_real_escape_string($con, $referenciaIdActualizada);
		$resultado=mysqli_query($con, "UPDATE referencias SET FECHA_CONTABLE = '$fechaActualizada', ASIENTO_CONTABLE = '$asientoActualizado', APUNTE_CONTABLE = '$apunteActualizado' WHERE  ID_USUARIO =  '$referencia'");
		mysqli_close($con);  

		}
		
		
		if(!empty($referenciaIDEliminada)){

		$referencia=mysqli_real_escape_string($con, $referenciaIDEliminada);
		$resultado=mysqli_query($con, "DELETE FROM referencias WHERE ID_USUARIO = $referencia");
		mysqli_close($con);

		} 
		
		if(!empty($nuevaFecha) && !empty($nuevoAsiento)) {
		$resultado=mysqli_query($con, "INSERT INTO referencias (FECHA_CONTABLE, ASIENTO_CONTABLE, APUNTE_CONTABLE, APERTURA_DEBE, APERTURA_HABER, DEBE_ASIENTO_ACTUAL, HABER_ASIENTO_ACTUAL, NUM_FACTURA, NUM_PEDIDO, NUM_ALBARAN, NUM_RECIBO) VALUES ('$nuevaFecha', '$nuevoAsiento', '0', '0', '0', '0', '0', '0', '0', '0', '0')");
		mysqli_close($con);
		} 
		
?>

