<?php 
	require "conexion.php";
 

	$cuentas="";
	$filtracodigo_cuenta="";
	$filtratitulo="";
	$filtramasa_patrimonial="";
	$filtragrado="";
	$filtradesarrollo="";
	$filtracon_enlace="";
	$codigo_cuentaActualizada="";
	$titulo_Actualizo="";
	$masa_patrimonialActualizada="";
	$gradoActualizado="";
	$desarrolloActualizado="";
	$con_enlaceActualizado="";
	
	$referenciaIDEliminada="";
	$nuevaCuenta="";
	$nuevoTitulo="";
	$nuevaMasaPatrimonial="";
	$nuevoGrado="";
	$nuevoDesarrollo="";
	$nuevoConEnlace="";
	$nuevaFecha="";
	$nuevoAsiento="";
	$acontar="no";
	$pagina=0;
	$num_paginas=0;
	$desde=0;
	$fechaHoy=0;
	$retrocedo="inicio";

	if (isset($_GET['cuentas'])) {
		$cuentas = $_GET['cuentas'];
		$pagina=$_GET['pagina'];
		$num_paginas=$_GET['num_paginas'];
		}

	if (isset($_GET['acontar'])) {
		$acontar="si";
		} else {
			$acontar="no";
		}
	
	
	if (isset($_GET['nuevaCuenta'])) {

		$nuevaCuenta=$_GET['nuevaCuenta'];
		$nuevoTitulo=$_GET['nuevoTitulo'];
		$nuevaMasaPatrimonial=$_GET['nuevaMasaPatrimonial'];
		$nuevoGrado=$_GET['nuevoGrado'];
		$nuevoDesarrollo=$_GET['nuevoDesarrollo'];
		$nuevoConEnlace=$_GET['nuevoConEnlace'];

	}

	if (isset($_GET['param1'])) {
		$codigo_cuentaActualizada = $_GET['param1'];
		}
	if (isset($_GET['param2'])){
		$tituloActualizado = $_GET['param2'];
		}
	if (isset($_GET['param3'])) {
		$masa_patrimonialActualizada = $_GET['param3'];
		}
	if (isset($_GET['param4'])){
		$gradoActualizado = $_GET['param4'];
		}
	if (isset($_GET['param5'])){
		$desarrolloActualizado = $_GET['param5'];
		}
	if (isset($_GET['param6'])){
		$con_enlaceActualizado = $_GET['param6'];
		}

	if (isset($_GET['refeliminada'])) {
		$referenciaIDEliminada=$_GET['refeliminada'];
	 	}


	$codigo_cuenta = "CODIGO_CUENTA";
	$titulo = "TITULO";
	$fecha_alta = "FECHA_ALTA";
	$apertura_debe="APERTURA_DEBE";
	$apertura_haber="APERTURA_HABER";
	$debe_anio="DEBE_ANIO";
	$haber_anio="HABER_ANIO";
	$masa_patrimonial="MASA_PATRIMONIAL";
	$grado="GRADO";
	$desarrollo="DESARROLLO";
	$con_enlace="CON_ENLACE";

	$actualizar ="ACTUALIZAR";
	$borrar = "BORRAR";
	$tamanio=12;
	
	if ($acontar=="si") {

		$resultado = mysqli_query($con, "SELECT * FROM cuentas");
		$num_filas = mysqli_num_rows($resultado);
		echo $num_filas;

	}


	if($cuentas==="cuentas") {

			
			$desde=(($pagina-1)*$tamanio);

		 	$resultado = mysqli_query($con, "SELECT * FROM cuentas LIMIT $desde,$tamanio");


			$table = '<div class = "container">';
			$table .=  '<table class = "table table-striped table-bordered table-hover table-condensed table-responsive">';
			$table .= '<tr>';
			$table .= '<th class="col-sm-2">Codigo Id</th>';
			$table .= '<th class="col-sm-12">Titulo</th>';
			$table .= '<th class="col-sm-2">Fecha Alta</th>';
			$table .= '<th class="col-sm-2">Debe apertura</th>';
			$table .= '<th class="col-sm-2">Haber apertura</th>';
			$table .= '<th class="col-sm-2">Debe año</th>';
			$table .= '<th class="col-sm-2">Haber año</th>';
			$table .= '<th class="col-sm-2">Masa Patrimonial</th>';
			$table .= '<th class="col-sm-2">Grado</th>';
			$table .= '<th class="col-sm-2">Desarrollo</th>';
			$table .= '<th class="col-sm-2">Con Enlace</th>';
			$table .= '<th class="col-sm-2">Modificar</th>';
			$table .= '<th class="col-sm-2">Eliminar</th>';
			$table .= '</tr>';


			while ($fila = mysqli_fetch_assoc($resultado)) {

			$table .= '<tr>';
			$table .= '<td id="'.$codigo_cuenta.$fila['CODIGO_CUENTA'].'">' . $fila['CODIGO_CUENTA'] . '</td>';
			$table .= '<td id="'.$titulo.$fila['CODIGO_CUENTA'].'">' . $fila['TITULO'] . '</td>';
			$table .= '<td id="'.$fecha_alta.$fila['CODIGO_CUENTA'].'">' . $fila['FECHA_ALTA'] . '</td>';
			$table .= '<td id="'.$apertura_debe.$fila['CODIGO_CUENTA'].'">' . $fila['APERTURA_DEBE'] . '</td>';
			$table .= '<td id="'.$apertura_haber.$fila['CODIGO_CUENTA'].'">' . $fila['APERTURA_HABER'] . '</td>';
			$table .= '<td id="'.$debe_anio.$fila['CODIGO_CUENTA'].'">' . $fila['DEBE_ANIO'] . '</td>';
			$table .= '<td id="'.$haber_anio.$fila['CODIGO_CUENTA'].'">' . $fila['HABER_ANIO'] . '</td>';
			$table .= '<td id="'.$masa_patrimonial.$fila['CODIGO_CUENTA'].'">' . $fila['MASA_PATRIMONIAL'] . '</td>';
			$table .= '<td id="'.$grado.$fila['CODIGO_CUENTA'].'">' . $fila['GRADO'] . '</td>';
			$table .= '<td id="'.$desarrollo.$fila['CODIGO_CUENTA'].'">' . $fila['DESARROLLO'] . '</td>';
			$table .= '<td id="'.$con_enlace.$fila['CODIGO_CUENTA'].'">' . $fila['CON_ENLACE'] . '</td>';

			$table .= '<td><input id="'.$fila['CODIGO_CUENTA'].'" onclick="editarCuentas(this.id)" type = "button" value ="Editar" class = "btn btn-success"></td>';
			$table .= '<td><input  id="'.$borrar.$fila['CODIGO_CUENTA'].'" onclick="borrarCuenta('.$fila['CODIGO_CUENTA'].')"  type = "button" value ="Borrar" class = "btn btn-danger"></td>';

			
 /* 			$table .= '<td><input id="'.$actualizar.$fila['CODIGO_CUENTA'].'" onclick = "actualizarCuentas('.$fila['CODIGO_CUENTA'].')" type = "button" value ="Actualizar" class = "btn btn-primary" style="display:none;"></td>';  		
 	*/
 		$texto="'";
  		$table .= '<td><input id="'.$actualizar.$fila['CODIGO_CUENTA'].'" onclick = "actualizarCuentas('.$texto.$fila['CODIGO_CUENTA'].$texto.')" type = "button" value ="Actualizar" class = "btn btn-primary" style="display:none;"></td>'; 
 

		
			$table .= '</tr>';
	}
		$table.= '</table>';
		$table.= '<button onclick="ejecutarNuevaVentana()" class="btn btn-primary">Agregar Cuentas</button>';
		$table.="<br>";
		$table.="<h4>Mostrar Página:</h4>";
		$table.="<button class='botones' onclick="."retrocedoPagina(".'"inicio"'.")"." id=".">".'<<'."</button>";
		$table.="<button class='botones' onclick="."'retrocedoPagina()'>"."<"."</button>";



		for ($i=0; $i<$num_paginas;$i++) {

		$table.="<button class='botones' onclick="."mostrarCuentas(".($i+1).")"." id="."boton".($i+1).">".($i+1)."</button>";
		
			} 

		$table.="<button  class='botones' onclick="."'avanzoPagina()'>".">"."</button>";
		$table.="<button class='botones' onclick="."avanzoPagina(".'"final"' .','.$num_paginas.")"." id=".">".'>>'."</button>";


		$table.= "</div>";
		echo $table;
		mysqli_close($con);
	} 



		if(!empty($codigo_cuentaActualizada)) {

		$filtracodigo_cuenta=mysqli_real_escape_string($con, $codigo_cuentaActualizada);
		$filtratitulo=mysqli_real_escape_string($con, $tituloActualizado);
		$filtramasa_patrimonial=mysqli_real_escape_string($con, $masa_patrimonialActualizada);
		$filtragrado=mysqli_real_escape_string($con, $gradoActualizado);
		$filtradesarrollo=mysqli_real_escape_string($con, $desarrolloActualizado);
		$filtracon_enlace=mysqli_real_escape_string($con, $con_enlaceActualizado);

	
		$query="UPDATE cuentas SET TITULO = '$filtratitulo', MASA_PATRIMONIAL = '$filtramasa_patrimonial', GRADO = '$filtragrado', DESARROLLO='$filtradesarrollo', CON_ENLACE ='$filtracon_enlace' WHERE  CODIGO_CUENTA =  $filtracodigo_cuenta";
		 

		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No correcto". mysqli_error($con);
		}
		mysqli_close($con); 
	}
		
		
		if(!empty($referenciaIDEliminada)){

		$referencia=mysqli_real_escape_string($con, $referenciaIDEliminada);
		$resultado=mysqli_query($con, "DELETE FROM referencias WHERE ID_USUARIO = $referencia");
		mysqli_close($con);

		} 
		
		if(!empty($nuevaCuenta)) {


		$query="INSERT INTO cuentas(CODIGO_CUENTA, TITULO, FECHA_ALTA, MASA_PATRIMONIAL, GRADO, DESARROLLO, CON_ENLACE) VALUES ('$nuevaCuenta', '$nuevoTitulo', '2020-10-23', '$nuevaMasaPatrimonial', '$nuevoGrado', '$nuevoDesarrollo', '$nuevoConEnlace')";

		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No ejecutado".mysqli_error($con);
		}


		/*$resultado=mysqli_query($con, "INSERT INTO cuentas (CODIGO_CUENTA, TITULO, FECHA_ALTA, APERTURA_DEBE, APERTURA_HABER, DEBE_ANIO, HABER_ANIO, MASA_PATRIMONIAL, GRADO, DESARROLLO, CON_ENLACE) VALUES ('$nuevaCuenta', '$nuevoTitulo', '2020-10-23' '0', '0', '0', '0', '$nuevaMasaPatrimonial', '$nuevoGrado', '$nuevoDesarrollo', '$nuevoConEnlace')");*/
		mysqli_close($con);
	} 

?>

