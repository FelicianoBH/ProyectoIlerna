 				
<?php 
	session_start();

	require "conexion.php";
  
	$actualizarapunte="";
	$cambiarcuenta="";

	if (isset($_GET['cambiarcuenta'])) {
		$cambiarcuenta=$_GET['cambiarcuenta'];
	}
	if (isset($_GET['actualizarapunte'])) {
		$actualizarapunte=$_GET['actualizarapunte'];
	}

	if ($cambiarcuenta=="si") {

		$screen='<div class = "container">';
		$screen .= '<label style="margin-left:10%;">Codigo Cuenta: </label><input type="text" id ="nuevaCuentaId"  maxlength="12" /><br><br>';
		$screen .= '<label style="margin-left:11%;">Titulo: </label><input type="" id="nuevoTituloId"/><br><br>';
		$screen .='<button type="button" class="botones" onclick="ejecutarNuevaVentanaB()">Consulta </button>';
		$screen .='<button type="button" class="botones" onclick="ejecutarNuevaVentanaAlfaB()">Alfabetica</button>';
		$screen .= '<button type="button" class="botones" style="margin-left:10%;" onclick="buscarCuentaB()">Busca Cuenta </button>';
		$screen .= '<button type="button" class="botones" style="margin-left:10%;" onclick="validaCuentaNueva()">Validar </button>';
		$screen .='<div>';
		echo $screen;
	}

	if ($actualizarapunte="si"){

		$importe="";

		if($_GET['importedebe'])==0) {
					$importe=$_GET['importehaber'];
				} else {
					$importe=$_GET['importedebe'];
				}
	
		$query="UPDATE apuntes SET DOCUMENTO = '$_GET['documento']', ID_CONCEPTO = '$_GET['idconcepto']', CONCEPTO='$_GET['concepto']', DEBE_HABER=$_GET['debeohaber'], IMPORTE='$importe', CUENTA='$_GET['cuenta']', FECHA_REAL = '$_GET['fechareal']' WHERE  USUARIO = '$_GET['usuario']', FECHA= '$_GET['fecha']', ASIENTO = '$_GET['asiento']', APUNTE ='$_GET['apunte']' ";
		 
		if (mysqli_query($con, $query)) {
			echo "correcto";
		} else { 
			echo "No correcto". mysqli_error($con);
		}
		mysqli_close($con); 

	}

?>
